"use client";

import React from 'react';
import { Nunito, Radley, Caveat_Brush } from 'next/font/google';

const nunito = Nunito({ weight: ['400', '600', '700'], subsets: ['latin'] });
const nunitoTitle = Nunito({ weight: ['900'], subsets: ['latin'] });
const radley = Radley({ weight: ['400'], subsets: ['latin'], style: ['normal', 'italic'] });
const caveat = Caveat_Brush({ weight: ['400'], subsets: ['latin'] });

// Brand colors from the website
const C = {
  cream: '#FAF9F6',
  sage: '#5E8C6A',
  sageLight: '#E8F0EA',
  gold: '#D4A853',
  goldLight: '#FBF5E8',
  charcoal: '#1A1A1A',
  muted: '#6B6B6B',
  coverBg: '#f7f1db',
  brown: '#29231b',
};

export default function WorkbookPage() {
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className={`min-h-[100dvh] ${nunito.className}`} style={{ backgroundColor: C.cream, color: C.charcoal }}>
      
      {/* 🚀 Magic Print Scaler to prevent awkward page breaks! */}
      <style dangerouslySetInnerHTML={{__html: `
        @media print {
          /* Strip height constraints — let content breathe naturally */
          .min-h-\\[970px\\] {
            min-height: auto !important;
          }

          /* ============================================================
             PAGE TYPE 1: COVER PAGE — standalone, no page number needed
          ============================================================ */
          .cover-page {
            page-break-after: always !important;
            page-break-inside: avoid !important;
            min-height: 100vh !important;
          }

          /* ============================================================
             PAGE TYPE 2: FRONT MATTER — How to Use, TOC
          ============================================================ */
          .front-matter-page {
            page-break-before: always !important;
            page-break-after: always !important;
            page-break-inside: avoid !important;
            display: flex !important;
            flex-direction: column !important;
            min-height: 100vh !important;
          }

          /* ============================================================
             PAGE TYPE 3: CHAPTER TITLE PAGES — standalone, vertically centered
          ============================================================ */
          .chapter-title-page {
            page-break-before: always !important;
            page-break-after: always !important;
            page-break-inside: avoid !important;
            display: flex !important;
            flex-direction: column !important;
            justify-content: center !important;
            align-items: center !important;
            text-align: center !important;
            min-height: 100vh !important;
          }

          /* ============================================================
             PAGE TYPE 4: CONTENT SECTIONS — flow like a chapter book
          ============================================================ */
          .content-section {
            display: block !important;
            page-break-inside: auto !important;
            padding-top: 1.5rem !important;
            padding-bottom: 1.5rem !important;
          }

          /* ============================================================
             PAGE TYPE 5: WORKSHEET PAGES — self-contained units
          ============================================================ */
          .worksheet-page {
            page-break-before: always !important;
            page-break-inside: avoid !important;
            display: block !important;
            padding-top: 1rem !important;
            padding-bottom: 1rem !important;
          }

          /* Sub-element protection on worksheets */
          .worksheet-page .rounded-3xl,
          .worksheet-page .rounded-2xl,
          .worksheet-page .rounded-xl,
          .worksheet-page .shadow-sm,
          .worksheet-page .shadow-md,
          .worksheet-page .grid > div,
          .worksheet-prompt-box,
          .worksheet-fill-in-group,
          .worksheet-instruction-box {
            page-break-inside: avoid !important;
            break-inside: avoid !important;
          }

          /* ============================================================
             UNIVERSAL: Protect callout boxes in content sections too
          ============================================================ */
          .callout-box, .quote-box, .highlight-box,
          .fill-in-box, .prompt-card, .input-area {
            page-break-inside: avoid !important;
            break-inside: avoid !important;
          }

          /* Protect ALL rounded/shadowed card elements from splitting across pages.
             This catches every callout box, quote box, tip box, instruction box, etc. */
          .content-section .rounded-3xl,
          .content-section .rounded-2xl,
          .content-section .rounded-xl,
          .content-section .shadow-sm,
          .content-section .shadow-md {
            page-break-inside: avoid !important;
            break-inside: avoid !important;
          }

          /* Protect border-left styled callout boxes */
          .content-section [style*="border-left"],
          .content-section [style*="borderLeft"] {
            page-break-inside: avoid !important;
            break-inside: avoid !important;
          }

          /* Protect all rounded card elements from being sliced */
          p, li, svg, img {
            page-break-inside: avoid !important;
            break-inside: avoid !important;
          }

          /* Prevent orphan section headers */
          .section-header, h1, h2, h3, h4, h5, h6 {
            page-break-after: avoid !important;
            break-after: avoid !important;
          }
        }
      `}} />

      {/* 🛠️ Non-printable Header Controls */}
      <div className="print:hidden fixed top-0 w-full bg-white shadow-md p-6 z-50 flex justify-between items-center px-8 border-b-4" style={{ borderColor: C.sage }}>
        <div>
          <h1 className="font-bold text-xl" style={{ color: C.charcoal }}>Your ADHD Workbook Prototype</h1>
          <p className="text-sm text-gray-500">The "Blah Is Gone" Edition! High-end Editorial Layout.</p>
        </div>
        <button 
          onClick={handlePrint}
          className="px-6 py-6 rounded-lg font-bold text-white shadow-md transition-all hover:opacity-90 active:scale-95 flex items-center gap-2"
          style={{ backgroundColor: C.sage }}
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4" /></svg>
          Save to PDF
        </button>
      </div>

      <div className="print:hidden h-28"></div>

      {/* 📄 The Printable Document */}
      <div className="max-w-[800px] mx-auto bg-white print:bg-transparent shadow-2xl print:shadow-none pb-20">
        
        {/* --- PAGE 1: COVER --- */}
        <section className="cover-page min-h-[970px] relative flex flex-col overflow-hidden" style={{ backgroundColor: C.cream }}>
          
          {/* Outer framing border */}
          <div className="absolute inset-6 border-[8px] z-10 pointer-events-none" style={{ borderColor: C.sage }}></div>

          {/* Inner content — justify-between so sections fill the page top-to-bottom */}
          <div className="flex flex-col h-full min-h-[970px] px-14 pt-20 pb-14 z-20 justify-between">

            {/* Top label */}
            <div className="text-center border-b-[3px] pb-6 relative z-0" style={{ borderColor: C.gold }}>
              <h2 className={`${radley.className} text-[34px] tracking-[0.2em] uppercase font-bold`} style={{ color: C.sage }}>
                The ADHD Workbook
              </h2>
              <p className="text-[16px] tracking-[0.4em] uppercase mt-1 font-black opacity-70" style={{ color: C.charcoal }}>
                For Getting Unstuck
              </p>
            </div>

            {/* Title block — fills middle space */}
            <div className="flex flex-col items-center justify-center flex-grow py-6" style={{ gap: 0 }}>
              {/* Curved "Manipulating" */}
              <svg width="100%" height="100%" viewBox="0 0 760 180" className="overflow-visible relative z-10 max-w-[650px] mx-auto" style={{ marginTop: '0px', marginBottom: '-80px' }}>
                <path id="titleCurve" d="M 20,160 Q 380,0 740,160" fill="transparent" />
                <text style={{ fontFamily: caveat.style.fontFamily, fontSize: '165px', fill: C.charcoal }}>
                  <textPath href="#titleCurve" startOffset="50%" textAnchor="middle">
                    Manipulating
                  </textPath>
                </text>
              </svg>

              <span className={`${caveat.className} block text-center`} style={{ color: C.sage, fontSize: '125px', lineHeight: 0.9 }}>Myself to</span>
              <span className={`${caveat.className} block text-center relative`} style={{ fontSize: '150px', lineHeight: 0.95, color: C.charcoal }}>
                Do Stuff
                <svg className="absolute -bottom-5 left-0 w-full h-8" viewBox="0 0 200 16" fill="none">
                  <path d="M5 12 Q 50 3, 100 10 T 195 3" stroke={C.gold} strokeWidth="5" strokeLinecap="round" />
                </svg>
              </span>
            </div>

            {/* Bottom row: description pill + photo + name — pinned to bottom */}
            <div className="flex items-end gap-8">
              
              {/* Left: compact description */}
              <div className="flex-1 rounded-3xl p-7 border-l-[8px]" style={{ backgroundColor: C.goldLight, borderColor: C.gold }}>
                <p className="text-[16px] font-black uppercase tracking-[0.2em] mb-2" style={{ color: C.sage }}>What&apos;s inside:</p>
                <p className="text-[19px] font-bold leading-snug" style={{ color: C.charcoal }}>
                  The art of bribing yourself, the 7 Commandments of ADHD systems &amp; other research-informed ways to trick yourself into doing stuff.
                </p>
              </div>

              {/* Right: Photo + name badge */}
              <div className="flex flex-col items-center gap-4" style={{ width: '310px', flexShrink: 0 }}>
                <div className="w-[280px] h-[280px] rounded-t-[140px] rounded-b-xl shadow-xl border-[10px] bg-white relative overflow-hidden" style={{ borderColor: C.sageLight }}>
                  <img src="/headshot-v2.jpg" className="w-full h-full object-cover absolute inset-0" alt="Liana Groombridge" onError={(e) => e.currentTarget.style.display = 'none'} />
                </div>
                <div className="bg-white px-6 py-4 shadow-xl rounded-2xl text-center border-b-[6px] w-full" style={{ borderColor: C.sage }}>
                  <p className={`${radley.className} font-bold text-[26px] leading-tight`} style={{ color: C.charcoal }}>Liana Groombridge</p>
                  <p className="font-black tracking-[0.2em] uppercase text-[13px] mt-1" style={{ color: C.gold }}>ACC, CACP</p>
                </div>
              </div>

            </div>
          </div>
        </section>



        {/* --- PAGE 2: EYE-CATCHING INTRO --- */}
        <section className="front-matter-page relative px-20 pt-20 px-20 pt-20 flex flex-col pb-32" style={{ backgroundColor: C.cream }}>
          <h1 className={`${radley.className} text-[60px] text-center mb-10 leading-tight border-b-4 pb-6 inline-block mx-auto`} style={{ color: C.charcoal, borderColor: C.gold }}>
            How to Use This Workbook 
          </h1>
          
          <div className="grid grid-cols-2 gap-6 mb-10">
            <div className="bg-white p-6 rounded-3xl shadow-md border-t-[8px]" style={{ borderColor: C.sage }}>

              <h3 className="font-bold text-xl mb-2">No Rules Apply</h3>
              <p className="text-[17px] text-gray-700 leading-snug">Write in pen, pencil, crayon, or whatever’s closest. Doesn’t matter. Just write. If you abandon this for 3 months and come back to it, that’s not failure, that’s just how this goes.</p>
            </div>
            
            <div className="bg-white p-6 rounded-3xl shadow-md border-t-[8px]" style={{ borderColor: C.gold }}>

              <h3 className="font-bold text-xl mb-2">Skip Around</h3>
              <p className="text-[17px] text-gray-700 leading-snug">This workbook doesn’t require you to start at Chapter 1. Flip to whatever chapter matches today’s crisis. Welcome back.</p>
            </div>
          </div>

          <div className="p-10 rounded-3xl relative my-8" style={{ backgroundColor: '#ebf2ed' }}>
            <h3 className={`${caveat.className} text-[56px] mb-10 leading-none transform -rotate-1`} style={{ color: C.sage }}>Why "manipulating"?</h3>
            <p className="text-[21px] leading-relaxed text-gray-800 font-medium z-10 relative">
              Because your brain doesn’t respond to “just try harder.” It responds to being outsmarted. Every strategy in this book is a way of rigging the game so your brain cooperates — not because it wants to, but because you gave it no good reason not to.
            </p>
          </div>

          <div className="mt-10 space-y-4 pt-10 border-t-[3px] border-dotted" style={{ borderColor: C.gold }}>
            <h4 className="font-black text-lg uppercase tracking-widest text-[#6B6B6B]">Two Quick Notes</h4>
            <div className="flex flex-col gap-6">
              <p className="text-[17px] text-gray-700 leading-snug"><strong>The Research:</strong> Everything in the “Real Talk” sections comes from peer-reviewed studies and recognized experts. I’ve included sources at the end. But if you have specific medical questions, please talk with your doctor or a medical professional.</p>
              <p className="text-[17px] text-gray-700 leading-snug"><strong>Blocker Types:</strong> These are patterns I’ve noticed that describe the most common ways ADHD gets in the way. They are not clinical diagnoses or medical terminology. If you’ve taken the “Why Can’t I Just Do the Thing?” quiz, you'll see more around those blockers in chapter 4 (Frozen starter), chapter 5 (Boredom blackout), chapter 6 (Overthinking looper), chapter 7 (Shame spiraler), and chapter 8 (System hopper).</p>
            </div>
          </div>
        </section>

        {/* --- PAGE 3: TABLE OF CONTENTS --- */}
        <section className="front-matter-page relative px-20 pt-20 px-20 pt-20 flex flex-col pb-32" style={{ backgroundColor: '#ffffff' }}>
          <h1 className={`${caveat.className} text-[56px] mb-10 text-center decoration-wavy underline-offset-8 drop-shadow-sm`} style={{ color: C.gold }}>
            Table of Contents
          </h1>
          
          <div className="space-y-4 max-w-2xl mx-auto w-full">
            {[
              { num: 1, title: 'Why Am I Like This?', page: 4 },
              { num: 2, title: 'The Art of Bribing Yourself', page: 11 },
              { num: 3, title: 'Making Future Me Do It', page: 15 },
              { num: 4, title: 'Tricking Myself Into Starting', page: 20 },
              { num: 5, title: 'Doing the Boring Stuff Without Dying', page: 26 },
              { num: 6, title: 'When My Brain Won\'t Shut Up', page: 32 },
              { num: 7, title: 'The Shame Spiral (and How to Climb Out)', page: 40 },
              { num: 8, title: 'Building Systems That Actually Stick', page: 46 },
              { num: 9, title: 'When You Can\'t Even Manipulate Yourself', page: 51 },
            ].map((chapter) => (
              <div key={chapter.num} className="flex items-center group">
                <div className={`${caveat.className} text-[32px] w-16 text-center shadow-sm rounded-full h-16 flex items-center justify-center flex-shrink-0 transition-transform group-hover:scale-110 border-[2px]`} style={{ backgroundColor: C.cream, color: C.sage, borderColor: C.sageLight }}>
                  {chapter.num}
                </div>
                <div className="ml-6 flex-grow border-b-[2px] border-dotted pb-2 flex justify-between items-baseline" style={{ borderColor: C.sageLight }}>
                  <span className={`${radley.className} text-[24px] tracking-wide font-bold`} style={{ color: C.charcoal }}>
                    {chapter.title}
                  </span>
                  <span className={`${nunito.className} font-black text-[18px] opacity-40 ml-4`}>
                    {chapter.page.toString().padStart(2, '0')}
                  </span>
                </div>
              </div>
            ))}
          </div>


        </section>

        {/* --- PAGE 4: CHAPTER 1 TITLE --- */}
        <section className="chapter-title-page min-h-[970px] flex flex-col justify-center items-center text-center px-20 py-20" style={{ backgroundColor: C.cream }}>
          <h1 className={`${caveat.className} text-[110px] leading-none mb-10 tracking-wide drop-shadow-md`} style={{ color: C.charcoal }}>
            CHAPTER 1
          </h1>
          <h2 className={`${radley.className} text-[56px] italic drop-shadow-sm px-8 relative`} style={{ color: C.sage }}>
            Why Am I Like This?
          </h2>
          <svg className="mt-12 w-48 h-12" viewBox="0 0 200 40" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M5 20 Q 50 5, 100 20 T 195 20" stroke={C.gold} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>


        </section>

        {/* --- PAGE 5: CHAPTER 1 CONTENT --- */}
        <section className="content-section min-h-[970px] relative px-20 pt-20 px-20 pt-20 bg-white pb-32">
          <div className="space-y-4 text-[17px] leading-[1.6]">
            <h2 className={`${radley.className} text-[35px] mb-10 border-b-4 inline-block font-bold`} style={{ color: C.sage, borderColor: C.sage }}>THE BIT</h2>
            
            <p>There’s a specific moment, and if you’re reading this, you’ve probably had it — where you’re scrolling through a list of ADHD symptoms at midnight and you go very, very quiet. Not because it’s relatable. Lots of things are relatable. This is different. This is “oh no, that thing I thought was a character flaw might be a whole neurological situation” quiet.</p>
            <p>Maybe it was a TikTok. Maybe it was a BuzzFeed quiz you took “as a joke.” Maybe it was sitting across from a therapist who said the letters A-D-H-D and your brain went, “Hmm. Well. That explains the last 30 years.”</p>
            <p>For me, it wasn’t a doctor’s appointment or a dramatic breakdown. It was a Tuesday night, working on a school project with a friend who has ADHD. She’d say something like “sorry, this is my ADHD, I have to —” and then do something I did every single day of my life. She’d laugh about her chaotic notes. I’d look down at mine. Same chaos. She’d mention how many tabs she had open. I’d quietly count mine. She’d talk about how she couldn’t start things until the pressure hit. I was sitting right next to her, having also not started this project until the day it was due. We crushed that project, by the way. But I left that night with a very inconvenient question I couldn’t stop thinking about.</p>

            <div className="my-10 p-6 rounded-3xl text-center shadow-md border-t-[8px]" style={{ backgroundColor: C.goldLight, borderColor: C.gold }}>
              <p className={`${caveat.className} text-[36px] leading-snug`} style={{ color: C.charcoal }}>
                "Because here’s the thing nobody warns you about: once you see it, you can’t unsee it."
              </p>
            </div>

            <p>Every “quirky” thing you do — the mountain of half-finished projects chilling in your garage and closets, the time blindness that has you showing up 20 minutes late to everything including things you were excited about, the way you can memorize the entire discography of a band you discovered yesterday but cannot remember to buy toilet paper, suddenly has an explanation.</p>
            <p>And it’s not “you’re lazy.” It’s not “you don’t care enough.” And it’s DEFINITELY not “you just need to try harder.” It’s that your brain is running on a fundamentally different operating system.</p>
            <p>It works differently. Not wrong. Just differently. In a way that makes certain things that seem simple for other people feel like you’re trying to sprint through wet concrete. And that’s what this chapter is about.</p>
            <p className="font-bold px-6 py-8 rounded-xl shadow-sm" style={{ backgroundColor: '#ebf2ed', color: C.charcoal }}>
              Not fixing you. Understanding you. Because you can’t manipulate yourself into doing stuff if you don’t understand what you’re working with. Consider this the “getting to know each other” chapter between you and your own brain, which, let’s be honest, you’ve likely been in a complicated relationship with your entire life.
            </p>

            {/* Transition bridge — kept inside content flow, not a standalone page */}
            <div className="mt-16 text-center">
              <span className={`${caveat.className} text-[42px]`} style={{ color: C.gold }}>So. Let’s figure out what you’re working with.</span>
              <div className="mt-4 text-5xl" style={{ color: C.sage }}>↓</div>
              <p className="text-center italic text-[17px] text-[#6B6B6B] max-w-xl mx-auto leading-relaxed mt-6">The following pages are your first workbook exercises. There’s no wrong way to do these. Write in pen, pencil, or whatever’s within arm’s reach.</p>
            </div>
          </div>

          {/* PAGE NUMBER */}
        </section>

        {/* --- PAGE 6: REAL TALK --- */}
        <section className="content-section min-h-[970px] relative px-20 pt-20 px-20 pt-20 pb-32" style={{ backgroundColor: C.cream }}>
          <div className="space-y-4 text-[17px] leading-[1.6]">
            <h2 className={`${radley.className} text-[35px] mb-10 border-b-4 inline-block font-bold`} style={{ color: C.sage, borderColor: C.sage }}>THE REAL TALK</h2>
            <p>If you've ever wondered why focus-based ADHD advice never quite works for you, there's a reason. ADHD is often described as an attention disorder, but attention is really just the most visible symptom. Underneath it is something bigger — and once you see it, a lot of things start to make sense.</p>
            <p>Dr. Russell Barkley, whose research has shaped much of how we understand ADHD today, argues that ADHD isn't really about attention at all — it's a developmental problem of self-regulation: the ability to manage your own behavior, plan ahead, and follow through <span className="uppercase text-xs opacity-60 tracking-wider font-bold">(Barkley, 1997)</span>.</p>
            <p>In his book, Taking Charge of Adult ADHD, he identifies seven executive functions — basically, the mental abilities your brain uses to manage itself. Things like working memory (holding information in your head long enough to use it), inhibition (hitting the brakes before you act), emotion regulation, self-motivation, and planning. These are the behind-the-scenes tools that let you start things, stick with things, manage your feelings about said things, and actually follow through <span className="uppercase text-xs opacity-60 tracking-wider font-bold">(Barkley & Benton, 2022, pp. 69–70)</span>.</p>
            <div className="my-8 p-6 rounded-3xl text-center shadow-md border-t-[8px]" style={{ backgroundColor: C.sageLight, borderColor: C.sage }}>
              <p className={`${caveat.className} text-[36px] leading-snug`} style={{ color: C.charcoal }}>
                "When those tools aren't firing reliably, it looks a lot like 'not trying hard enough.'"
              </p>
            </div>
            <p>But it's not. It's more like trying to build furniture with half the tools missing — you can see exactly what needs to happen, but you can't make your hands do it. If you've ever walked into a room and forgotten why you're there, retained approximately one-third of one step from a three-step instruction, or felt a small criticism land like a gut punch, that's not a character flaw. That's executive function doing its thing. Or rather, not doing its thing.</p>
            <p>This matters because it changes the entire conversation. You're not failing at being a functional adult because you're not trying hard enough. You're working with a brain that is wired differently — and that's not a metaphor.</p>
            
            <div className="p-6 rounded-2xl shadow-sm border-l-[6px] my-6" style={{ backgroundColor: '#ffffff', borderColor: C.gold }}>
              <p className="font-bold text-[20px] leading-snug" style={{ color: C.charcoal }}>
                Research on the neurobiology of ADHD has shown that the prefrontal cortex, the part of your brain responsible for all those executive functions we just talked about, needs the right balance of two chemicals called dopamine and norepinephrine to do its job. In ADHD brains, that balance is off <span className="uppercase text-xs opacity-60 tracking-wider font-bold">(Arnsten, 2009)</span>.
              </p>
            </div>
            
            <p>Think of it like a car that runs on two types of fuel, and the supply is inconsistent. Some days the tank is full and you're flying. Other days you're running on fumes and nothing moves.</p>
            
            <p className="print:break-before-page font-bold text-[21px] mt-10 mb-10">Now, here's the part I wish someone had told me sooner:</p>
            
            <p>There's a second piece to the chemistry puzzle, and it's the one that explains why some tasks feel impossible while others are effortless. Beyond the focus and self-regulation piece, the ADHD brain also has an under-responsive dopamine reward system — meaning tasks that aren't inherently interesting or personally meaningful don't generate enough signal for your brain to lock in and sustain effort <span className="uppercase text-xs opacity-60 tracking-wider font-bold">(Volkow et al., 2011)</span>. That's why you can spend hours focused on something you love but struggle to unload the dishwasher. It's not that you don't care. It's that your brain works wonderfully when a task is genuinely engaging, and stalls when it isn't. The trick is learning how to work with that chemistry instead of against it — and the rest of this workbook is about figuring out how to create those conditions on purpose.</p>
          </div>
        </section>

        {/* --- PAGE 6B: THE MANIPULATION --- */}
        <section className="content-section min-h-[970px] relative px-20 pt-20 px-20 pt-20 pb-32" style={{ backgroundColor: '#ffffff' }}>
          <div className="space-y-4 text-[17px] leading-[1.6]">
            <h2 className={`${radley.className} text-[35px] mb-10 border-b-4 inline-block font-bold`} style={{ color: C.sage, borderColor: C.sage }}>THE MANIPULATION</h2>
            <p className="font-bold text-2xl">The first manipulation is the least sexy one: you have to actually understand what you’re dealing with.</p>
            <p>I know. I can feel your eyes glazing over. “I didn’t buy a workbook for a neuroscience lecture.” Fair. And to be quite honest with you, although I love to quote a good research article, I’m not a neuroscientist. But here’s why this matters:</p>
            <p>Every strategy in this book — every bribe (more on this in chap. 2), every hack, every emergency checklist — works better when you understand why it works. When you know that your brain struggles with working memory, you stop trying to “just remember” things and start writing everything down without feeling like that makes you less capable. When you know that your motivation system runs on interest and urgency instead of importance, you stop beating yourself up for not caring about your taxes and start finding ways to make your taxes feel urgent or interesting (or at least pair them with something that is).</p>
            <div className="p-6 rounded-3xl mt-10 shadow-sm border-[3px]" style={{ backgroundColor: C.cream, borderColor: C.sageLight }}>
              <p className="font-bold text-xl mb-10" style={{ color: C.sage }}>Self-knowledge isn’t a warm fuzzy motivational concept here. It’s tactical information.</p>
              <p>You’re gathering intel on how your specific brain operates so you can build systems that work WITH it instead of against it.</p>
            </div>
            <p>The workbook pages in this chapter are designed to help you map your own patterns. Not ADHD in general — YOUR ADHD specifically. Because ADHD shows up differently in everyone. Some people are the “can’t sit still” type. Some are the “sitting perfectly still while my brain runs a marathon” type. Some are both, depending on the day. Some of us got diagnosed at 7, some at 37, and some are reading this right now thinking “I should probably make that appointment.”</p>
            <p>Whatever your version is, it’s worth understanding. Because that understanding is the foundation everything else in this book is built on.</p>
          </div>
        </section>

        {/* --- WORKSHEET: MY ADHD GREATEST HITS --- */}
        <section className="worksheet-page min-h-[970px] relative px-20 pt-20 px-20 pt-20 pb-32" style={{ backgroundColor: '#ffffff' }}>
          <h1 className={`${caveat.className} text-[60px] text-center mb-4 leading-tight mt-10 drop-shadow-sm`} style={{ color: C.charcoal }}>
            My ADHD Greatest Hits
          </h1>
          <p className="text-center font-black tracking-[0.2em] uppercase text-sm mb-10" style={{ color: C.sage }}>Brain Dump Exercise</p>

          <div className="mb-5 p-4 rounded-3xl text-[15px] shadow-sm border-[3px]" style={{ borderColor: C.goldLight, backgroundColor: '#fafafa' }}>
            <p className="font-medium leading-snug"><span className="font-black text-sm uppercase tracking-widest" style={{ color: C.sage }}>Instructions:</span> List your top recurring ADHD moments — the patterns, the near-disasters, the “oh no, not again” situations. These aren’t failures. They’re data. The more honest you are here, the more useful the rest of this workbook becomes.</p>
          </div>

          <div className="mb-8 py-4 px-6 rounded-3xl text-center shadow-sm border-[3px]" style={{ backgroundColor: '#ebf2ed', borderColor: C.sageLight }}>
            <p className={`${radley.className} font-bold text-[22px] leading-snug`} style={{ color: C.charcoal }}>
              What are the situations, mistakes, or patterns that keep showing up in my life?
            </p>
          </div>
          

          <div className="grid grid-cols-1 gap-3 relative z-10 pb-4">
            {[
              "It’s challenging to maintain...",
              "The thing I struggle the most with on a daily basis is...",
              "A common \"oh no, not again\" situation is...",
              "I always forget to...",
              "People in my life have pointed out that I...",
              "The thing I procrastinate on most is...",
              "Other:"
            ].map((text, i) => (
              <div key={i} className="bg-white rounded-2xl h-[52px] border-2 shadow-sm relative overflow-hidden px-5 pt-3" style={{ borderColor: '#e2dec9' }}>
                 <p className="opacity-60 italic text-[13px] font-bold text-[#6B6B6B]">{text}</p>
                 <div className="absolute bottom-3 left-5 right-5 border-b-[2px] border-dotted" style={{ borderColor: '#e2dec9' }}></div>
              </div>
            ))}
          </div>

          {/* PAGE NUMBER */}
        </section>

        {/* --- PAGE 7B: WORKSHEET 2 --- */}
        <section className="worksheet-page min-h-[970px] relative px-20 pt-20 px-20 pt-20 pb-32" style={{ backgroundColor: '#ffffff' }}>
          <h1 className={`${caveat.className} text-[60px] text-center mb-4 leading-tight mt-10 drop-shadow-sm`} style={{ color: C.charcoal }}>
            My Brain’s Resume
          </h1>
          <p className="text-center font-black tracking-[0.2em] uppercase text-sm mb-10" style={{ color: C.sage }}>Reflection Prompt</p>

          <div className="mb-5 p-4 rounded-3xl text-[15px] shadow-sm border-[3px]" style={{ borderColor: C.goldLight, backgroundColor: '#fafafa' }}>
            <p className="font-medium leading-snug"><span className="font-black text-sm uppercase tracking-widest" style={{ color: C.sage }}>Instructions:</span> We spend a lot of time cataloguing what ADHD makes harder. This page is about what your brain is actually good at. Not in a “look on the bright side!” toxic positivity way. In a “this is real information about how your brain works and you should use it” way.</p>
          </div>

          <div className="mb-8 py-4 px-6 rounded-3xl text-center shadow-sm border-[3px]" style={{ backgroundColor: '#ebf2ed', borderColor: C.sageLight }}>
            <p className={`${radley.className} font-bold text-[22px] leading-snug`} style={{ color: C.charcoal }}>
              If my brain were applying for a job, what would its qualifications be?
            </p>
          </div>
          
          <p className="text-center font-bold text-[#6B6B6B] italic mb-10">Fill in any or all:</p>

          <div className="grid grid-cols-2 gap-6 relative z-10">
            {([
              { label: "Things I can hyperfocus on:", sub: null },
              { label: "Weird connections I make that other people miss:", sub: null },
              { label: "Situations where I perform well", sub: "(crises? new challenges?)" },
              { label: "Skills that come naturally to me:", sub: null },
            ] as { label: string; sub: string | null }[]).map((item, i) => (
              <div key={i} className="bg-white rounded-2xl p-5 border-2 shadow-sm flex flex-col" style={{ borderColor: '#e2dec9' }}>
                <p className={`${radley.className} font-bold text-[16px] uppercase tracking-wide leading-snug min-h-[72px]`} style={{ color: C.sage }}>
                  {item.label}
                  {item.sub && <span className="text-[12px] normal-case tracking-normal font-normal ml-1 opacity-70"> {item.sub}</span>}
                </p>
                <div className="space-y-4 mt-4">
                  <div className="border-b-[2px] border-dotted w-full" style={{ borderColor: '#e2dec9' }}></div>
                  <div className="border-b-[2px] border-dotted w-full" style={{ borderColor: '#e2dec9' }}></div>
                  <div className="border-b-[2px] border-dotted w-full" style={{ borderColor: '#e2dec9' }}></div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-10 grid grid-cols-1 gap-6 relative z-10 pb-10">
            <div className="bg-white rounded-2xl p-6 border-2 shadow-sm flex flex-col gap-6" style={{ borderColor: '#e2dec9' }}>
              <p className={`${radley.className} font-bold text-[16px] uppercase tracking-wide`} style={{ color: C.sage }}>A moment where my brain impressed even me:</p>
              <div className="space-y-4 px-2">
                <div className="border-b-[2px] border-dotted w-full" style={{ borderColor: '#e2dec9' }}></div>
                <div className="border-b-[2px] border-dotted w-full" style={{ borderColor: '#e2dec9' }}></div>
              </div>
            </div>
            <div className="bg-white rounded-2xl p-6 border-[3px] shadow-sm flex flex-col pt-8 text-center" style={{ borderColor: C.goldLight }}>
              <p className={`${caveat.className} font-bold text-4xl mb-10`} style={{ color: C.charcoal }}>If I could bottle one thing about how my brain operates and sell it, it would be...</p>
              <div className="space-y-8 mb-10 px-4">
                <div className="w-full border-b-[3px] border-dotted" style={{ borderColor: C.sageLight }}></div>
                <div className="w-full border-b-[3px] border-dotted" style={{ borderColor: C.sageLight }}></div>
              </div>
            </div>
          </div>
        </section>

        {/* --- PAGE 7C: WORKSHEET 3 --- */}
        <section className="worksheet-page min-h-[970px] relative px-20 pt-20 px-20 pt-20 pb-32" style={{ backgroundColor: '#ffffff' }}>
          <h1 className={`${caveat.className} text-[60px] text-center mb-4 leading-tight mt-10 drop-shadow-sm`} style={{ color: C.charcoal }}>
            My ADHD Origin Story
          </h1>
          <p className="text-center font-black tracking-[0.2em] uppercase text-sm mb-10" style={{ color: C.sage }}>Reflection Prompt</p>

          <div className="mb-5 p-4 rounded-3xl text-[15px] shadow-sm border-[3px]" style={{ borderColor: C.goldLight, backgroundColor: '#fafafa' }}>
            <p className="font-medium leading-snug"><span className="font-black text-sm uppercase tracking-widest" style={{ color: C.sage }}>Instructions:</span> This one’s more personal. You don’t have to write a novel — a few sentences is fine. But there’s something powerful about putting your story on paper. When you name the moment everything clicked (or started to), it stops being this vague background noise and becomes something you can actually look at.</p>
          </div>
          
          <p className="text-center font-bold text-[#6B6B6B] italic mb-10 px-10">
            If you haven’t been formally diagnosed — that’s okay. This page is for everyone. Diagnosed at 5, diagnosed at 50, or still figuring it out.
          </p>

          <div className="grid grid-cols-1 gap-5 relative z-10 pb-12">
            {[
              "When did I first suspect something was different about how my brain worked?",
              "What was the moment (video, article, breakdown) that made me think 'this might be ADHD'?",
              "What’s the thing I most wish people understood about my experience?",
              "What do I want to get out of this workbook?"
            ].map((text, i) => (
              <div key={i} className="bg-white rounded-xl p-6 border-2 shadow-sm relative pt-[26px]" style={{ borderColor: '#e2dec9' }}>
                <p className="absolute -top-6 bg-white px-4 py-1 border-2 font-bold text-sm uppercase rounded-full shadow-sm" style={{ color: C.charcoal, borderColor: '#e2dec9' }}>Prompt {i+1}</p>
                <p className="font-bold text-[15px] mb-6" style={{ color: C.sage }}>{text}</p>
                <div className="w-full border-b-2 border-dotted mb-10" style={{ borderColor: '#e2dec9' }}></div>
                <div className="w-full border-b-2 border-dotted" style={{ borderColor: '#e2dec9' }}></div>
              </div>
            ))}
          </div>
        </section>

        {/* --- PAGE 8: CHAPTER 2 TITLE --- */}
        <section className="chapter-title-page min-h-[970px] flex flex-col justify-center items-center text-center px-20 py-20" style={{ backgroundColor: C.cream }}>
          <h1 className={`${caveat.className} text-[110px] leading-none mb-10 tracking-wide drop-shadow-md`} style={{ color: C.charcoal }}>
            CHAPTER 2
          </h1>
          <h2 className={`${radley.className} text-[56px] italic drop-shadow-sm px-8 relative`} style={{ color: C.sage }}>
            The Art of Bribing Yourself
          </h2>
          <svg className="mt-12 w-48 h-12" viewBox="0 0 200 40" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M5 20 Q 50 5, 100 20 T 195 20" stroke={C.gold} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </section>

        {/* --- PAGE 9: CHAPTER 2 CONTENT --- */}
        <section className="content-section min-h-[970px] relative px-20 pt-20 px-20 pt-20 bg-white pb-32">
          <div className="space-y-4 text-[17px] leading-[1.6]">
            <h2 className={`${radley.className} text-[35px] mb-10 border-b-4 inline-block font-bold`} style={{ color: C.sage, borderColor: C.sage }}>THE BIT</h2>
            <p>If I have a good audiobook or podcast I can almost guarantee I will complete ALL the laundry, including my husband’s (lucky him, I know), and clean my entire house spotless. In fact, as I write this, I have this exciting urge to pop in my headphones and get cleaning. Wild, I know.</p>
            
            <div className="my-8 p-6 rounded-3xl text-center shadow-md border-t-[8px]" style={{ backgroundColor: C.goldLight, borderColor: C.gold }}>
              <p className={`${caveat.className} text-[36px] leading-snug`} style={{ color: C.charcoal }}>
                I don’t clean because the house needs cleaning. I clean because I found something interesting enough to pair with it.
              </p>
            </div>
            
            <p>My brain suddenly decided to cooperate. Not because the task mattered — because the bribe did. If you’ve ever done something you’d been avoiding for weeks simply because you found the right podcast, the right playlist, or the right snack to go with it, you already know how this works.</p>

            <p className="font-bold px-6 py-8 rounded-xl shadow-sm" style={{ backgroundColor: '#ebf2ed', color: C.charcoal }}>
              Your brain doesn’t respond to “you should do this because it’s important.” It responds to “oh, this is kind of enjoyable now.”
            </p>
            <p>That’s not a willpower failure. That’s your brain being very honest about what it needs. And this chapter is all about learning what that is.</p>
          </div>
        </section>

        {/* --- PAGE 10: REAL TALK --- */}
        <section className="content-section min-h-[970px] relative px-20 pt-20 px-20 pt-20 pb-32" style={{ backgroundColor: C.cream }}>
          <div className="space-y-4 text-[17px] leading-[1.6]">
            <h2 className={`${radley.className} text-[35px] mb-10 border-b-4 inline-block font-bold`} style={{ color: C.sage, borderColor: C.sage }}>THE REAL TALK</h2>
            <p>Dr. William Dodson, a board-certified psychiatrist who has specialized in ADHD for over 25 years, has a question he asks almost every client: “If you could get engaged and stay engaged, has there ever been anything you couldn’t do?” Almost universally, the answer is no. The issue was never ability. It was engagement.</p>
            <div className="my-8 p-6 rounded-2xl shadow-sm border-l-[6px]" style={{ backgroundColor: '#ffffff', borderColor: C.sage }}>
              <p className="font-bold text-[24px] leading-snug" style={{ color: C.charcoal }}>
                Dodson coined the term “interest-based nervous system” to explain how the ADHD brain motivates itself.
              </p>
            </div>
            
            <p>Most people operate on what he calls an “importance-based nervous system”. They can motivate themselves to do things because they’re important, because there’s a reward later, or because there are consequences if they don’t. The ADHD nervous system doesn’t work that way. It runs on what Dodson identifies as:</p>

            <div className="my-8 p-6 rounded-3xl shadow-sm border-[3px] bg-white relative overflow-hidden" style={{ borderColor: C.goldLight }}>
               <p className={`${radley.className} text-[24px] font-bold mb-10 tracking-widest border-b-2 pb-2 inline-block`} style={{ color: C.sage, borderColor: C.gold }}>I.N.C.U.P.</p>
               
               <div className="space-y-6 relative z-10">
                 {[
                   { letter: 'I', text: 'Interest' },
                   { letter: 'N', text: 'Novelty' },
                   { letter: 'C', text: 'Competition (or Challenge)' },
                   { letter: 'U', text: 'Urgency' },
                   { letter: 'P', text: 'Passion' }
                 ].map((item, i) => (
                   <div key={i} className="flex items-center gap-6">
                     <div className="flex items-center justify-center w-10 h-10 rounded-full font-black text-lg shadow-sm border-2" style={{ backgroundColor: C.goldLight, color: C.charcoal, borderColor: C.gold }}>
                       {item.letter}
                     </div>
                     <p className="font-bold text-[17px] tracking-wide" style={{ color: C.charcoal }}>{item.text}</p>
                   </div>
                 ))}
               </div>
               <p className="mt-10 text-xs font-bold opacity-40 tracking-widest uppercase text-left">(Dodson, 2022)</p>
            </div>

            <p>If a task doesn’t trigger at least one of those, your brain won’t produce the dopamine needed to engage — no matter how important the task is.</p>
            <p>This is why you can spend four hours learning everything about a topic you discovered an hour ago but can’t spend 15 minutes filing your taxes. It’s not about discipline. It’s that your brain’s motivation system requires a specific kind of fuel, and “I should” isn’t it.</p>
            <p>The manipulation, then, is straightforward: if your brain won’t do the thing because it’s important, attach something to the task that IS interesting, novel, challenging, or urgent. That’s a bribe. And it works.</p>

            <div className="mt-12 pt-10 border-t-[3px] border-dashed space-y-4" style={{ borderColor: '#e2dec9' }}>
              <h2 className={`${radley.className} text-[35px] mb-10 font-bold`} style={{ color: C.sage }}>THE MANIPULATION</h2>
              
              <p>Here’s what most reward system advice gets wrong about ADHD: it assumes you’ll do the hard thing first and then give yourself a treat after. “Finish your emails, then you can have the chocolate.” Sounds reasonable. Except if you’re anything like me, you’re going to eat the chocolate anyway. The “after” reward has no leverage because your brain lives in right now, not later.</p>
              
              <p>So forget the after. The real manipulation is making the task itself less miserable, or making the environment around it appealing enough that your brain agrees to show up in the first place.</p>
              
              <p className="font-black text-[25px] my-10 text-center" style={{ color: C.gold }}>
                The bribe isn’t a prize at the finish line. The bribe is what you add to the experience so your brain will actually start.
              </p>
              
              <p>That looks like: putting on a podcast you’re obsessed with so you can tolerate doing dishes. Making your third iced coffee of the day and bringing it to your desk before you open your inbox. Lighting your favorite candle in the room where you do your admin work. Moving to a coffee shop because the ambient noise and the latte make the task 40% less painful.</p>
              
              <p>You’re not rewarding yourself for doing the task. You’re bribing your brain into the room where the task happens.</p>
              
              <p>One more thing — and I mean this: a reward is also allowing yourself to stop and say...</p>
              
              <div className="my-10 p-6 rounded-2xl shadow-sm border-l-[6px]" style={{ backgroundColor: '#ffffff', borderColor: C.sage }}>
                <p className={`${caveat.className} font-bold text-[33px] text-center`} style={{ color: C.charcoal }}>
                  “f*ck yeah, I just SMASHED that task”
                </p>
              </div>
              
              <p>...and genuinely letting yourself feel good about it. We are so quick to move on to the next thing or immediately think about what we didn’t do. Pausing to actually acknowledge that you did something hard? That’s a bribe too. And it’s free.</p>
              
              <div className="my-8 p-6 rounded-2xl border-2" style={{ backgroundColor: '#fff5f5', borderColor: '#ffe0e0' }}>
                <p className="font-bold uppercase text-[15px] tracking-widest mb-3" style={{ color: '#c53030' }}>A warning about phone scrolling:</p>
                <p className="leading-snug" style={{ color: '#742a2a' }}>I know it’s tempting to put “10 minutes of scrolling” on your bribe list. Don’t. For most ADHD brains, picking up your phone for “just 10 minutes” is how you lose an hour and a half and then feel worse than before you started. Scrolling isn’t a reward — it’s a trap with a dopamine-shaped entrance and a shame-shaped exit. Keep your phone out of the bribe menu.</p>
              </div>

            </div>
          </div>
        </section>

        
        {/* Transition bridge — bottom of preceding content, NOT standalone */}
        <div className="mt-16 text-center pb-10 content-section">
<span className={`${caveat.className} text-[60px]`} style={{ color: C.gold }}>Let's get to it.</span>
          <span className="animate-bounce mt-6 text-6xl" style={{ color: C.sage }}>↓</span>
          <p className="text-center italic text-[20px] text-[#6B6B6B] max-w-2xl mx-auto leading-relaxed mt-8">Two exercises for this chapter. The first helps you figure out what actually drives you. The second gives you a tool to use that information every day.</p>
        </div>


        {/* --- PAGE 11: WORKSHEET 1 --- */}
        <section className="worksheet-page min-h-[970px] relative px-20 pt-20 px-20 pt-12 flex flex-col pb-32" style={{ backgroundColor: '#ffffff' }}>
          <h1 className={`${caveat.className} text-[60px] text-center mb-2 leading-tight mt-10 drop-shadow-sm`} style={{ color: C.charcoal }}>
            What Actually Motivates Me?
          </h1>
          <p className="text-center font-black tracking-[0.2em] uppercase text-sm mb-10" style={{ color: C.sage }}>Reflection Prompt</p>

          <div className="mb-10 p-6 rounded-3xl text-[17px] shadow-sm border-[3px] flex-shrink-0" style={{ borderColor: C.goldLight, backgroundColor: '#fafafa' }}>
            <p className="font-medium leading-snug"><span className="font-black text-sm uppercase tracking-widest" style={{ color: C.sage }}>Instructions:</span> Think about the last few times you got something done without a fight. What was present? Check the ones that apply and add your own.</p>
          </div>

          <div className="bg-white rounded-2xl p-5 border-2 shadow-sm mb-10" style={{ borderColor: '#e2dec9' }}>
            <p className="font-bold text-[15px] mb-3" style={{ color: C.charcoal }}>I’m most likely to do something when... <span className="font-normal text-[12px] text-gray-400">(check all that apply)</span></p>
            <div className="grid grid-cols-2 gap-y-3 gap-x-6">
              {[
                "It’s genuinely interesting to me", "It’s brand new or novel",
                "Someone’s watching or waiting for me", "There’s a deadline breathing down my neck",
                "I turned it into a competition", "There’s an immediate reward",
                "I changed my environment", "I’m slightly angry or spiteful",
                "I’m doing it with or alongside someone else", "I’d feel embarrassed if I didn’t do it"
              ].map((text, i) => (
                <div key={i} className="flex items-center gap-2">
                  <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"><rect x="15" y="15" width="70" height="70" rx="8"/></svg>
                  <span className="text-[13px] text-gray-700">{text}</span>
                </div>
              ))}
              {[1, 2].map(i => (
                <div key={`blank-${i}`} className="flex items-center gap-2">
                  <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"><rect x="15" y="15" width="70" height="70" rx="8"/></svg>
                  <div className="flex-grow border-b-[2px] border-dotted mt-3" style={{ borderColor: '#e2dec9' }}></div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="px-6 py-8 rounded-xl mb-10 flex-shrink-0" style={{ backgroundColor: '#ebf2ed' }}>
            <p className="italic text-[15px] font-medium leading-snug" style={{ color: C.charcoal }}>
              <span className="font-bold">Psst!</span> If you checked spite, anger, or embarrassment — I get it. Sometimes it works. But those are emergency fuel, not a daily driver. They’ll get you through a task, but they’ll burn you out if you rely on them. Notice them, use them when they show up, but try to build your systems around the other motivators on this list.
            </p>
          </div>

          <div className="bg-white rounded-2xl p-5 border-2 shadow-sm mb-10 flex-shrink-0" style={{ borderColor: C.goldLight }}>
            <p className="font-bold text-[15px] mb-6" style={{ color: C.sage }}>My top 3 motivators (the ones I should build into my life on purpose):</p>
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-end gap-3 w-full">
                  <span className={`${radley.className} font-bold text-2xl mb-[-4px]`} style={{ color: C.sage }}>{i}.</span>
                  <div className="flex-grow border-b-[2px] border-dotted mt-3" style={{ borderColor: '#e2dec9' }}></div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="bg-white rounded-2xl p-5 border-2 shadow-sm flex-shrink-0" style={{ borderColor: C.sageLight }}>
            <p className="font-bold text-[15px] mb-6" style={{ color: C.charcoal }}>One task I’ve been avoiding + a motivator I could attach to it:</p>
            <div className="flex flex-col gap-6 mt-6 mb-2">
              <div className="flex items-end gap-3 w-full">
                <span className="font-bold text-[13px] mb-[-4px] uppercase tracking-widest text-[#6B6B6B]">Task:</span>
                <div className="flex-grow border-b-[2px] border-dotted mt-3" style={{ borderColor: '#e2dec9' }}></div>
              </div>
              <div className="flex items-end gap-3 w-full">
                <span className="font-bold text-[13px] mb-[-4px] uppercase tracking-widest text-[#6B6B6B]">Motivator:</span>
                <div className="flex-grow border-b-[2px] border-dotted mt-3" style={{ borderColor: '#e2dec9' }}></div>
              </div>
            </div>
          </div>
        </section>

        {/* --- PAGE 12: WORKSHEET 2 --- */}
        <section className="worksheet-page min-h-[970px] relative px-20 pt-20 px-20 pt-12 flex flex-col pb-32" style={{ backgroundColor: '#ffffff' }}>
          <h1 className={`${caveat.className} text-[56px] text-center mb-2 leading-tight mt-10 drop-shadow-sm`} style={{ color: C.charcoal }}>
            My Bribe Menu
          </h1>
          <p className="text-center font-black tracking-[0.2em] uppercase text-sm mb-10" style={{ color: C.sage }}>Action Planning Template</p>

          <div className="mb-10 p-6 rounded-3xl text-[17px] shadow-sm border-[3px] flex-shrink-0" style={{ borderColor: C.goldLight, backgroundColor: '#fafafa' }}>
            <p className="font-medium leading-snug"><span className="font-black text-sm uppercase tracking-widest" style={{ color: C.sage }}>Instructions:</span> Now that you know what motivates you, build your personal bribe list around it. Most of these should be things you can add DURING or BEFORE the task — not after.</p>
          </div>

          <div className="space-y-4 flex-shrink-0 relative z-10">
            {[
              { title: "SENSORY UPGRADES", subtext: "Things that make your environment more appealing. (Candle, cozy blanket, fancy drink)" },
              { title: "TASK STACKING", subtext: "Things you enjoy that you can pair WITH the boring task. (Audiobook, podcast, FaceTime)" },
              { title: "ENVIRONMENT SHIFTS", subtext: "Places or setups that make you more likely to start. (Coffee shop, library, outside)" },
              { title: "THE PAUSE & CELEBRATE", subtext: "Ways to acknowledge you did the thing. (Say it out loud, text someone, take a breath)" },
              { title: "AFTER-TASK REWARDS", badge: "(optional bonus)", subtext: "A little note: these are fun to have, but rarely strong enough to carry you alone. Add an extra incentive here as a bonus on top of the bribes above, or skip entirely." },
            ].map((section, idx) => (
              <div key={idx} className="bg-white rounded-2xl p-5 border-2 shadow-sm" style={{ borderColor: '#e2dec9' }}>
                <p className="font-bold text-[15px] mb-2 flex items-baseline gap-2" style={{ color: C.sage }}>
                  {section.title}
                  {section.badge && <span className="font-sans text-[12px] normal-case tracking-normal opacity-70 italic font-medium" style={{ color: C.charcoal }}>{section.badge}</span>}
                </p>
                <p className="text-[#6B6B6B] text-[13px] italic mb-3">{section.subtext}</p>
                <div className="space-y-4">
                  <div className="border-b-2 border-dotted h-4 w-full" style={{ borderColor: '#e2dec9' }}></div>
                  <div className="border-b-2 border-dotted h-4 w-full" style={{ borderColor: '#e2dec9' }}></div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* --- PAGE 15: CHAPTER 3 TITLE --- */}
        <section className="chapter-title-page min-h-[970px] flex flex-col justify-center items-center text-center px-20 py-20" style={{ backgroundColor: C.cream }}>
          <h1 className={`${caveat.className} text-[110px] leading-none mb-10 tracking-wide drop-shadow-md`} style={{ color: C.charcoal }}>
            CHAPTER 3
          </h1>
          <h2 className={`${radley.className} text-[56px] italic drop-shadow-sm px-8 relative`} style={{ color: C.sage }}>
            Making Future Me Do It
          </h2>
          <svg className="mt-12 w-48 h-12" viewBox="0 0 200 40" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M5 20 Q 50 5, 100 20 T 195 20" stroke={C.gold} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </section>

        {/* --- PAGE 16: CHAPTER 3 CONTENT - THE BIT --- */}
        <section className="content-section min-h-[970px] relative px-20 pt-20 px-20 pt-20 bg-white pb-32">
          <div className="space-y-4 text-[17px] leading-[1.6]">
            <h2 className={`${radley.className} text-[35px] mb-10 border-b-4 inline-block font-bold`} style={{ color: C.sage, borderColor: C.sage }}>THE BIT</h2>
            <div className="my-8 p-6 rounded-2xl border-l-[6px] shadow-sm" style={{ backgroundColor: '#ffffff', borderColor: C.sage }}>
              <p className="font-bold text-[24px]" style={{ color: C.charcoal }}>
                Here's the most underrated ADHD skill:
              </p>
              <p className={`${caveat.className} text-[30px] leading-none drop-shadow-sm`} style={{ color: C.gold }}>
                being kind to future-you.
              </p>
            </div>
            
            <p>Not in a bubble-bath, self-care-Sunday kind of way (which sounds equally amazing) but in a practical, "I am going to make your life structurally easier before you even get there" kind of way.</p>
            <p>Think of it like this: if you had a coworker who was brilliant and creative but couldn't be trusted to remember a message, find their own keys, or pick an outfit before 9am, you wouldn't keep leaving all of that up to that coworker and getting mad when it fell apart. You'd set things up for them. You'd put the message in their inbox. You'd hang their keys by the door. You'd lay their clothes out the night before. Not because something's wrong with that coworker, but because you know how their brain works so you design around it.</p>
            <p>That coworker is future-you. And this chapter is about becoming the person who sets things up for future-you — so the right thing happens whether future-you is firing on all cylinders or barely holding it together.</p>
            
            <div className="my-8 p-6 rounded-3xl text-center shadow-sm border-2 font-bold text-[24px]" style={{ backgroundColor: '#ebf2ed', borderColor: C.sageLight, color: C.charcoal }}>
              <p>It's not a workaround because something's wrong with you. It's a workaround because ADHD brains are some of the most creative, resourceful problem-solvers out there, and this is just you applying that same creativity to yourself.</p>
            </div>
          </div>
        </section>

        {/* --- PAGE 17: REAL TALK --- */}
        <section className="content-section min-h-[970px] relative px-20 pt-20 px-20 pt-20 pb-32" style={{ backgroundColor: C.cream }}>
          <div className="space-y-4 text-[17px] leading-[1.6]">
            <h2 className={`${radley.className} text-[35px] mb-10 border-b-4 inline-block font-bold`} style={{ color: C.sage, borderColor: C.sage }}>THE REAL TALK</h2>
            <p>So why does designing around your brain actually work better than trying harder? The short answer: because the parts of your brain you'd normally rely on to remember, plan, and follow through aren't firing consistently, and the research backs that up.</p>
            <p>Dr. Russell Barkley's research points to working memory as one of the core executive functions that ADHD messes with. Working memory is your brain's ability to hold onto information long enough to actually act on it, and in ADHD, it's a tad bit unreliable.</p>
            
            <div className="my-8 p-6 rounded-2xl shadow-sm border-l-[6px]" style={{ backgroundColor: '#ffffff', borderColor: C.sage }}>
              <p className="font-bold text-[24px] leading-snug" style={{ color: C.charcoal }}>
                This is why "I'll remember to do that later" is basically a promise your brain makes with full confidence and absolutely zero follow-through.
              </p>
              <p className="mt-10 text-xs font-bold opacity-40 tracking-widest uppercase text-left">
                (Barkley, 1997)
              </p>
            </div>
            
            <p>But here's the part that really matters for this chapter: Barkley also points out that ADHD makes it hard to use internal cues to guide behavior. In other words, leaning on your own memory, your own motivation, or your own "I should really do that" feeling is setting yourself up to fail. Not because you're careless, but because those internal signals just don't fire consistently in an ADHD brain.</p>
            <div className="my-8 p-6 rounded-2xl shadow-sm border-l-[6px]" style={{ backgroundColor: '#ffffff', borderColor: C.sage }}>
              <p className="font-bold text-[24px] leading-snug" style={{ color: C.charcoal }}>
                Barkley's fix is pretty clear: when internal self-regulation isn't pulling its weight, you compensate by changing the environment around you.
              </p>
            </div>
            
            <p>In his own words, the goal is to fill your surroundings with "physical cues comparable to their internal counterparts" so you're not stuck relying on a system that keeps letting you down <span className="uppercase text-xs opacity-60 tracking-wider font-bold">(Barkley, n.d.)</span>. When the cue to act lives outside your brain, like a sticky note, an alarm, a pre-set environment, or a default routine, you don't need to remember. You just respond.</p>
            <p>Dr. J. Russell Ramsay, who co-founded the University of Pennsylvania's Adult ADHD Treatment and Research Program, lands in the exact same place. In his book Rethinking Adult ADHD, he describes the core challenge of ADHD not as a knowledge problem but as an implementation problem: you know what to do, you just can't consistently make yourself do it. His fix? Externalized coping reminders, meaning strategies and cues that live outside your head so they can nudge you at the exact time and place you actually need them <span className="uppercase text-xs opacity-60 tracking-wider font-bold">(Ramsay, 2020)</span>.</p>
            
            <p className="font-black text-2xl my-10 text-center" style={{ color: C.gold }}>
              That's the manipulation: stop asking your brain to hold things — start designing your environment to hold them for you.
            </p>
          </div>
        </section>

        {/* --- PAGE 18: THE MANIPULATION --- */}
        <section className="content-section min-h-[970px] relative px-20 pt-20 px-20 pt-12 bg-white flex flex-col justify-between pb-32">
          <div className="space-y-4 text-[17px] leading-[1.6]">
            <h2 className={`${radley.className} text-[35px] mb-10 font-bold border-b-4 inline-block pb-1`} style={{ color: C.sage, borderColor: C.sageLight }}>THE MANIPULATION</h2>
            
            <p>So if the science says "stop relying on your brain and start relying on your environment," what does that actually look like on a Tuesday morning when you're already running late? This is where it gets practical, because there's a second piece to this that nobody talks about: every time you ask your brain to remember, decide, or muster the willpower to do something, it costs you something real.</p>
            
            <p>There's a concept called the Spoon Theory, originally created by Christine Miserandino to explain life with chronic illness. The idea is simple: you start each day with a limited number of "spoons," and every task costs you some. Once they're gone, they're gone <span className="uppercase text-xs opacity-60 tracking-wider font-bold">(Miserandino, 2003)</span>. For people with ADHD, this maps perfectly onto executive function.</p>
            
            <div className="my-8 p-6 rounded-2xl shadow-sm border-l-[6px]" style={{ backgroundColor: C.goldLight, borderColor: C.gold }}>
              <p className="font-bold text-[25px] leading-snug" style={{ color: C.charcoal }}>
                Every decision you make, every task you initiate, every time you have to remember something, it costs you a spoon.
              </p>
            </div>
            
            <p>And ADHD brains start the day with fewer spoons than most, while tasks cost more spoons than they would for a neurotypical person.</p>
            
            <p>So when Barkley and Ramsay say to externalize your cues and design your environment, this is why it matters so much. Every cue you move out of your head and into your environment is a spoon you don't have to spend. Every decision you delete before it happens is a spoon you get to keep for the stuff that actually matters. This chapter isn't really about being more organized. It's about conserving your spoons.</p>
            
            <p className="font-bold text-2xl text-center mt-12 mb-10" style={{ color: C.charcoal }}>
              The fix is deleting decisions before they happen:
            </p>
            
            <div className="space-y-4 bg-[#fafafa] p-6 rounded-3xl border-2" style={{ borderColor: '#e2dec9' }}>
              <div className="flex gap-6">
                <span className={`${caveat.className} text-[36px] mt-[-6px]`} style={{ color: C.sage }}>1.</span>
                <p><span className="font-bold" style={{ color: C.charcoal }}>Automate the recurring stuff.</span> Auto-pay your bills. Set up recurring grocery orders. Use calendar reminders for everything, and let the apps handle the remembering so your brain doesn't have to.</p>
              </div>
              <div className="flex gap-6">
                <span className={`${caveat.className} text-[36px] mt-[-6px]`} style={{ color: C.sage }}>2.</span>
                <p><span className="font-bold" style={{ color: C.charcoal }}>Pre-decide the daily stuff.</span> Lay out tomorrow's clothes tonight. Make a list of meals you'll eat this week so you don't end up standing in front of the fridge at 6pm with decision paralysis. (Okay, in an ideal world you'd meal prep on Sunday. But you and I both know that's probably not going to happen consistently, so having a list of "I could make this" options is the realistic version that actually works.) Hang a hook by the door for your keys, not because you're neat, but because hunting for keys requires executive function you don't have at 8am.</p>
              </div>
              <div className="flex gap-6">
                <span className={`${caveat.className} text-[36px] mt-[-6px]`} style={{ color: C.sage }}>3.</span>
                <p><span className="font-bold" style={{ color: C.charcoal }}>Set traps for your future self.</span> Put your vitamins next to your coffee maker. Leave the thing you need to take with you in front of the door. Set your laptop on your desk with the document already open. Make the right thing the easy thing and the wrong thing the hard thing.</p>
              </div>
            </div>
            
            <div className="mt-10 p-6 rounded-2xl shadow-sm border-l-[6px]" style={{ backgroundColor: C.cream, borderColor: C.gold }}>
              <p className={`${radley.className} font-bold text-[21px] text-center`} style={{ color: C.charcoal }}>
                Every one of these saves you a spoon. And those saved spoons add up. That's the difference between running out of mental energy by 2pm and actually having something left for the evening.
              </p>
            </div>

          </div>
        </section>

        
        {/* Transition bridge — bottom of preceding content, NOT standalone */}
        <div className="mt-16 text-center pb-10 content-section">
<span className={`${caveat.className} text-[60px]`} style={{ color: C.gold }}>Let's get to it.</span>
          <span className="animate-bounce mt-6 text-6xl" style={{ color: C.sage }}>↓</span>
          <p className="text-center italic text-[20px] text-[#6B6B6B] max-w-2xl mx-auto leading-relaxed mt-8">Two exercises for this chapter. The first is an audit of where decisions are draining you. The second is a concrete plan for making tomorrow easier tonight.</p>
        </div>


        {/* --- PAGE 18: WORKSHEET 1 --- */}
        <section className="worksheet-page min-h-[970px] relative px-20 pt-20 px-20 pt-12 flex flex-col pb-32" style={{ backgroundColor: '#ffffff' }}>
          <h1 className={`${caveat.className} text-[56px] text-center mb-2 leading-tight mt-10 drop-shadow-sm`} style={{ color: C.charcoal }}>
            Decisions I Can Delete
          </h1>
          <p className="text-center font-black tracking-[0.2em] uppercase text-sm mb-10" style={{ color: C.sage }}>Checklist + Action Plan</p>

          <div className="mb-10 p-6 rounded-3xl text-[17px] shadow-sm border-[3px] flex-shrink-0" style={{ borderColor: C.sageLight, backgroundColor: '#fafafa' }}>
            <p className="font-medium leading-snug"><span className="font-black text-sm uppercase tracking-widest" style={{ color: C.sage }}>Instructions:</span> Below are some common areas where decisions pile up, with a few examples to get you thinking. But your drains might be completely different. Fill in the ones that apply to YOUR day. For each one, write one way you could automate, pre-decide, or remove that decision entirely.</p>
          </div>
          
          <div className="mb-10 text-[15px] italic text-[#6B6B6B] px-8">
            <span className="font-bold" style={{ color: C.charcoal }}>An example:</span> Where is my gym pass? → I can attach my gym pass to my gym bag
          </div>

          <div className="space-y-4 flex-shrink-0 relative z-10 w-full flex-grow">
            {[
              { title: "GETTING READY / LEAVING THE HOUSE:", subtext: "Common ones: what to wear, what to eat, where your stuff is, whether to take meds" },
              { title: "WORK / PRODUCTIVITY:", subtext: "Common ones: what to start on, where to work, when to take a break" },
              { title: "HOME / HOUSEHOLD / CAREGIVING:", subtext: "Common ones: what’s for dinner, when to do laundry, kid/pet logistics, grocery shopping, chores" },
              { title: "EVENING / END OF DAY:", subtext: "Common ones: when to stop working, what to do with free time, when to go to bed" },
              { title: "ANYTHING ELSE THAT COSTS YOU SPOONS:", subtext: "" },
            ].map((section, idx) => (
              <div key={idx} className="bg-white rounded-2xl p-5 border-2 shadow-sm" style={{ borderColor: '#e2dec9' }}>
                <p className="font-bold text-[15px] mb-1 uppercase tracking-widest" style={{ color: C.sage }}>{section.title}</p>
                {section.subtext && <p className="text-[#6B6B6B] text-[12px] italic mb-10">{section.subtext}</p>}
                
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex items-end gap-3 w-full">
                      <div className="w-5 h-5 rounded border-2 flex-shrink-0 mb-[2px]" style={{ borderColor: C.sageLight }}></div>
                      <div className="w-1/3 border-b-[2px] border-dotted h-5" style={{ borderColor: '#e2dec9' }}></div>
                      <span className="font-bold text-[13px] mb-[-4px]" style={{ color: C.sage }}>→ I can:</span>
                      <div className="flex-grow border-b-[2px] border-dotted h-5" style={{ borderColor: '#e2dec9' }}></div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
            
            <div className="rounded-2xl px-8 py-6 mt-10 flex-shrink-0" style={{ backgroundColor: '#ebf2ed' }}>
              <p className="font-bold text-[17px] mb-10" style={{ color: C.sage }}>The 3 decisions that drain me the most:</p>
              <div className="space-y-4 mb-10 mt-2">
                {[1, 2, 3].map((num) => (
                  <div key={num} className="flex items-end gap-3 w-full">
                    <span className={`${radley.className} font-bold text-2xl mb-[-4px]`} style={{ color: C.sage }}>{num}.</span>
                    <div className="flex-grow border-b-[2px] border-dotted h-8" style={{ borderColor: '#acc2b6' }}></div>
                  </div>
                ))}
              </div>
              <p className="text-center font-bold tracking-[0.05em] uppercase text-[12px] pt-4" style={{ color: C.sage }}>
                Start with those three. Automate, pre-decide, or delete them this week.
              </p>
            </div>
          </div>
        </section>

        {/* --- PAGE 19: WORKSHEET 2 --- */}
        <section className="worksheet-page min-h-[970px] relative px-20 pt-20 px-20 pt-12 flex flex-col pb-32" style={{ backgroundColor: '#ffffff' }}>
          <h1 className={`${caveat.className} text-[56px] text-center mb-2 leading-tight mt-10 drop-shadow-sm`} style={{ color: C.charcoal }}>
            The Future Me Setup
          </h1>
          <p className="text-center font-black tracking-[0.2em] uppercase text-sm mb-10" style={{ color: C.sage }}>Action Planning Template</p>

          <div className="mb-10 p-6 rounded-3xl text-[17px] shadow-sm border-[3px] flex-shrink-0" style={{ borderColor: C.sageLight, backgroundColor: '#fafafa' }}>
            <p className="font-medium leading-snug"><span className="font-black text-sm uppercase tracking-widest" style={{ color: C.sage }}>Instructions:</span> For each day this week, write one specific thing you can set up TODAY that makes TOMORROW easier. These should be physical, concrete actions, not intentions. Not “I’ll try to be more organized.” More like “I’ll put my gym bag by the front door and set an alarm for 6:45.”</p>
          </div>

          <div className="bg-white rounded-2xl p-5 border-2 shadow-sm flex-shrink-0 mb-8" style={{ borderColor: '#e2dec9' }}>
            <table className="w-full text-left border-collapse table-fixed mt-2">
              <thead>
                <tr>
                  <th className="text-[12px] tracking-widest uppercase pb-4 font-black border-b-2 w-[25%]" style={{ borderColor: C.sageLight, color: C.charcoal }}>Day</th>
                  <th className="text-[12px] tracking-widest uppercase pb-4 font-black border-b-2 w-[55%]" style={{ borderColor: C.sageLight, color: C.charcoal }}>What I'll set up tonight</th>
                  <th className="text-[12px] tracking-widest uppercase pb-4 font-black border-b-2 text-center w-[20%] px-4" style={{ borderColor: C.sageLight, color: C.charcoal }}>Did I do it?</th>
                </tr>
              </thead>
              <tbody>
                {["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"].map((day, i) => (
                  <tr key={i} className="border-b border-dotted last:border-b-0" style={{ borderColor: '#e2dec9' }}>
                    <td className="py-5 font-bold text-[14px]" style={{ color: C.sage }}>{day}</td>
                    <td className="py-5"></td>
                    <td className="py-5">
                      <div className="flex justify-center">
                        <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round">
                          <rect x="15" y="15" width="70" height="70" rx="8" />
                        </svg>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="bg-white rounded-2xl p-5 border-2 shadow-sm flex-shrink-0 mb-6" style={{ borderColor: '#e2dec9' }}>
            <p className="font-bold text-[15px] mb-2" style={{ color: C.sage }}>My “I’ll remember” graveyard:</p>
            <p className="text-[13px] italic text-gray-400 mb-6">List 3 things you've said &quot;I'll remember&quot; about recently and absolutely did not remember. Then write where that information should actually live:</p>
            
            <table className="w-full text-left border-collapse table-fixed">
              <thead>
                <tr>
                  <th className={`text-[12px] tracking-widest uppercase pb-4 font-black border-b-2 w-[40%]`} style={{ borderColor: C.sageLight, color: C.charcoal }}>"I'll remember to..."</th>
                  <th className={`text-[12px] tracking-widest uppercase pb-4 font-black border-b-2 text-center w-[20%] px-4`} style={{ borderColor: C.sageLight, color: C.charcoal }}>Did I remember?</th>
                  <th className={`text-[12px] tracking-widest uppercase pb-4 font-black border-b-2 w-[40%] text-right`} style={{ borderColor: C.sageLight, color: C.charcoal }}>Where should it live instead?</th>
                </tr>
              </thead>
              <tbody>
                {[1, 2, 3].map((i) => (
                  <tr key={i} className="border-b border-dotted last:border-0" style={{ borderColor: '#e2dec9' }}>
                    <td className="py-6"></td>
                    <td className="py-6 text-center">
                      <div className="flex   gap-5 text-sm font-bold opacity-60">
                        <label className="flex items-center gap-2 cursor-pointer"><div className="w-5 h-5 rounded border-2" style={{ borderColor: '#d1cebd' }}></div> Yes</label>
                        <label className="flex items-center gap-2 cursor-pointer"><div className="w-5 h-5 rounded border-2" style={{ borderColor: '#d1cebd' }}></div> No</label>
                      </div>
                    </td>
                    <td className="py-6 relative">
                      <div className="w-full border-b-2 border-dotted absolute bottom-5" style={{ borderColor: '#e2dec9' }}></div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="mt-auto p-5 rounded-2xl text-center border-t-[4px]" style={{ backgroundColor: '#ffffff', borderColor: C.sage }}>
            <p className="text-[15px] font-medium leading-relaxed text-gray-700">
              You just took a bunch of decisions out of future-you’s hands. That’s not cheating, that’s strategy. Next up: what to do when you know exactly what you need to do but cannot physically make yourself start.
            </p>
          </div>
        </section>

        {/* --- PAGE 20: CHAPTER 4 TITLE --- */}
        <section className="chapter-title-page min-h-[970px] flex flex-col justify-center items-center text-center px-20 py-20" style={{ backgroundColor: C.cream }}>
          <h1 className={`${caveat.className} text-[110px] leading-none mb-10 tracking-wide drop-shadow-md`} style={{ color: C.charcoal }}>
            CHAPTER 4
          </h1>
          <h2 className={`${radley.className} text-[56px] italic drop-shadow-sm px-8 relative`} style={{ color: C.sage }}>
            Tricking Myself Into Starting
          </h2>
          <svg className="mt-12 w-48 h-12" viewBox="0 0 200 40" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M5 20 Q 50 5, 100 20 T 195 20" stroke={C.gold} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </section>

        {/* --- PAGE 21: CHAPTER 4 CONTENT - THE BIT --- */}
        <section className="content-section min-h-[970px] relative px-20 pt-20 bg-white pb-32">
          <div className="space-y-4 text-[17px] leading-[1.6]">
            <h2 className={`${radley.className} text-[35px] mb-10 border-b-4 inline-block font-bold`} style={{ color: C.sage, borderColor: C.sage }}>THE BIT</h2>
            <p>Tell me if this sounds familiar…I will sit on the couch for 45 minutes thinking about a task that takes 5 minutes. And I'm not thinking about the task in a productive way. I'm not planning. I'm not strategizing. I'm just... aware of it. It's sitting there. I'm sitting here. We're both very still. Neither of us is making the first move.</p>
            
            <p>It’s the world’s most ridiculous standoff.</p>
            
            <div className="my-6 p-6 rounded-2xl shadow-sm border-l-[6px] inline-block" style={{ backgroundColor: C.goldLight, borderColor: C.gold }}>
              <p className="font-bold text-[22px] leading-snug" style={{ color: C.charcoal }}>
                I call this one the Frozen Starter
              </p>
            </div>
            
            <p>...and before you ask, no, that’s not a clinical term. It’s just what I started calling it after dealing with it so many times that I literally felt like a frozen block of ice sitting on my couch. You’re not avoiding the task. You’re not distracted. You’re frozen in front of it.</p>
            
            <p>And the whole time, there’s a running narration in my head that goes something like: "I should start that. I'm going to start that. I'll start that in a minute. Okay, after this episode. Okay, after I refill my water. Okay, after I check one thing on my phone." And then it's 10pm and the task is still sitting there and now it's too late, which honestly feels like a relief, because at least I don't have to think about starting it anymore. I can just feel guilty about it instead.</p>

            <div className="my-10 p-8 rounded-3xl text-center shadow-md border-[3px]" style={{ backgroundColor: '#ebf2ed', borderColor: C.sageLight }}>
              <p className={`${radley.className} font-bold text-[30px] leading-relaxed`} style={{ color: C.charcoal }}>
                If someone told me to "just do it," I would simply explode. "Just do it" is not advice. It's a Nike slogan.
              </p>
            </div>
            
            <p>It works for people whose brains already have a reliable, easy to use start button. An ADHD brain however, has a start button, but requires a series of circumstances so specific and unpredictable that it might as well be a secret combination that you don't know. Ugh.</p>
          </div>
        </section>

        {/* --- PAGE 22: CHAPTER 4 CONTENT - THE REAL TALK --- */}
        <section className="content-section min-h-[970px] relative px-20 pt-20 pb-32" style={{ backgroundColor: C.cream }}>
          <div className="space-y-4 text-[17px] leading-[1.6]">
            <h2 className={`${radley.className} text-[35px] mb-10 border-b-4 inline-block font-bold`} style={{ color: C.sage, borderColor: C.sage }}>THE REAL TALK</h2>
            <p>So here's what's going on when you're glued to the couch staring at the thing you need to do. Your brain isn't being lazy. It's stuck. And not in a "I don't feel like it" way. In a "my body will not move and I don't know why" way. If you've ever wanted to do something, known exactly how to do it, had the time to do it, and still just... not done it, you know what I'm talking about.</p>

            <p>The research backs this up.</p>

            <div className="my-6 p-6 rounded-2xl shadow-sm border-l-[6px] inline-block" style={{ backgroundColor: C.goldLight, borderColor: C.gold }}>
              <p className="font-bold text-[22px] leading-snug" style={{ color: C.charcoal }}>
                Barkley's work shows that ADHD is fundamentally a disorder of self-regulation, not just attention.
              </p>
            </div>

            <p>It starts with a deficit in behavioral inhibition that cascades into problems with working memory, managing emotions and motivation, internal self-talk, and putting ideas together. Basically, the mental tools you need to get yourself to do things aren't firing reliably <span className="uppercase text-xs opacity-60 tracking-wider font-bold">(Barkley, 1997)</span>. That's why you can care deeply about something and still not be able to make yourself start it.</p>

            <p>In chemistry (don't worry, this is NOT turning into a chemistry book) there's a concept called activation energy: the minimum amount of energy required to start a chemical reaction. Once the reaction starts, it sustains itself with way less energy. Psychologist Shawn Achor uses this same metaphor in his book, The Happiness Advantage to explain why starting is the hardest part of any behavior change. He wanted to build a habit of playing guitar every day, and kept failing. When he looked at why, he realized the guitar was in his closet, and those 20 seconds of effort it took to walk over and pull it out were enough to stop him every time. So he bought a cheap guitar stand and put it in the middle of his living room. He played for 21 days straight.</p>

            <div className="my-8 p-6 rounded-2xl shadow-sm border-l-[6px]" style={{ backgroundColor: '#ffffff', borderColor: C.gold }}>
              <p className="font-bold text-[22px] leading-snug text-gray-800">
                His 20-Second Rule argues that reducing the effort to begin by even a tiny amount can be the difference between doing something and not doing it <span className="uppercase text-[12px] opacity-60 tracking-wider font-bold">(Achor, 2010)</span>.
              </p>
            </div>

            <p>Now, Achor wasn't talking about ADHD specifically. But if 20 seconds of extra effort can stop a neurotypical person from picking up a guitar, imagine what it does to a brain that's already low on the fuel it needs to get started.</p>

            <p>There's also an emotional piece to this that doesn't get talked about enough. A 2023 research review found that emotion dysregulation is increasingly recognized as a core component of ADHD. Adults with ADHD consistently scored lower on emotion regulation measures and tended to use less effective strategies for managing their emotional responses <span className="uppercase text-xs opacity-60 tracking-wider font-bold">(Soler-Gutiérrez et al., 2023)</span>. This shows up in task initiation all the time. It's not just that the task is hard or boring. It's that the task comes with feelings (dread, shame, overwhelm, perfectionism), and those feelings become their own barrier to starting.</p>
          </div>
        </section>

        {/* --- PAGE 23: CHAPTER 4 CONTENT - REAL TALK CONT. / MANIPULATION --- */}
        <section className="content-section min-h-[970px] relative px-20 pt-20 bg-white pb-32">
          <div className="space-y-4 text-[17px] leading-[1.6]">
            
            <p>And then there's the delay problem. A study looking at ADHD and procrastination found exactly what you'd expect: people with more ADHD symptoms procrastinate more. But here's the interesting part. The researchers found that two things helped explain why. The first is impulsiveness, which in this context means how much you discount future outcomes in favor of what's right in front of you. The second is low expectancy, which basically means not feeling confident that you can actually complete the task successfully <span className="uppercase text-xs opacity-60 tracking-wider font-bold">(Netzer Turgeman & Pollak, 2023)</span>.</p>
            
            <p>For example, that thing that's due in three weeks that you cannot make yourself start even though you know you'll panic about it later? The outcome is too far away and some part of you isn't convinced you can do it well anyway. So your brain just... doesn't.</p>

            <p className="font-bold px-6 py-6 rounded-xl shadow-sm my-8" style={{ backgroundColor: '#ebf2ed', color: C.charcoal }}>
              So no. You are not lazy, or whatever else you've been calling yourself. Your brain requires more activation energy to start, and it's getting less fuel than it needs. The manipulation is about making the start so small, so easy, and so low-cost that your brain just shrugs and goes, "can't argue with that."
            </p>

            <h2 className={`${radley.className} text-[35px] mt-16 mb-10 border-b-4 inline-block font-bold`} style={{ color: C.sage, borderColor: C.sage }}>THE MANIPULATION</h2>
            
            <p>The most important thing I can tell you about starting is this: you do not need to feel ready. You do not need to wait for motivation to show up on its own. But you do need to give your brain something it can work with. If you read Chapter 2, you already know your brain runs on interest, novelty, challenge, passion and urgency, not on "I should." So the trick isn't forcing yourself to start with nothing. It's making the first action so small, or the environment around it appealing enough, that your brain has just enough buy-in to take that first step.</p>

            <div className="my-8 p-6 rounded-2xl shadow-sm border-[3px]" style={{ borderColor: C.sageLight, backgroundColor: '#ffffff' }}>
               <p className={`${radley.className} text-[22px] font-bold tracking-wide leading-relaxed text-center`} style={{ color: C.charcoal }}>
                 Not "clean the kitchen." Put one plate in the sink.<br/>
                 Not "write the report." Open the document.<br/>
                 Not "do your taxes." Find the folder.
               </p>
            </div>

            <p>That's it. That's the trick. You're not committing to finishing anything. You're just starting. And once you start, your brain often keeps going, because continuing requires significantly less activation energy than initiating did. The reaction is already happening. You just needed the spark.</p>
            
          </div>
        </section>

        {/* --- PAGE 24: CHAPTER 4 CONTENT - MANIPULATION CONT --- */}
        <section className="content-section min-h-[970px] relative px-20 pt-20 pb-32" style={{ backgroundColor: C.cream }}>
          <div className="space-y-4 text-[17px] leading-[1.6]">
            
            <p>If even the smallest step feels impossible, check your environment. Are you trying to start from the couch? Move to the room where the task lives. Are you trying to start in silence? Put something on in the background. Sometimes the issue isn't the task at all. It's that you're trying to initiate from a location or a state your brain associates with rest, and the transition cost is too high. Changing your physical position can be the 20 seconds that makes the difference.</p>

            <div className="my-8 p-8 rounded-3xl shadow-sm border-[3px]" style={{ backgroundColor: '#ffffff', borderColor: C.sageLight }}>
              <p className="font-bold text-[18px] mb-4 uppercase tracking-widest text-center" style={{ color: C.sage }}>A brief note on body doubling:</p>
              <p className="text-[19px] leading-relaxed text-gray-800 text-center font-medium">
                If you can get someone, anyone, in the same room (or on a video call, or even a "Study With Me" livestream on YouTube), that presence alone can lower the activation energy enough to start. You don't need them to help. You don't need them to care. You just need them to exist near you.
              </p>
            </div>

            <p>And one more thing. If you try a strategy and it doesn't work, that's information, not failure. ADHD brains are novelty-seeking, which means the trick that worked on Tuesday might not work on Thursday. That's normal. Build a list of starting strategies so you have options. Which is exactly what the next exercise is for.</p>
            
          </div>
        </section>

        
        {/* Transition bridge — bottom of preceding content, NOT standalone */}
        <div className="mt-16 text-center pb-10 content-section">
<span className={`${caveat.className} text-[60px]`} style={{ color: C.gold }}>Let's get to it.</span>
          <span className="animate-bounce mt-6 text-6xl" style={{ color: C.sage }}>↓</span>
          <p className="text-center italic text-[20px] text-[#6B6B6B] max-w-2xl mx-auto leading-relaxed mt-8">Two exercises for this chapter. The first helps you figure out exactly what's blocking you and match it to a strategy. The second gives you a tool to shrink any task down to something your brain can actually start.</p>
        </div>


        {/* --- CHAPTER 4 WORKBOOK PAGE 1: Why I'm Stuck --- */}
        <section className="worksheet-page min-h-[970px] relative px-20 pt-20 px-20 pt-12 flex flex-col pb-32" style={{ backgroundColor: '#ffffff' }}>
          <h1 className={`${caveat.className} text-[60px] text-center mb-2 leading-tight mt-10 drop-shadow-sm`} style={{ color: C.charcoal }}>
            Why I&apos;m Stuck (and What Might Unstick Me)
          </h1>
          <p className="text-center font-black tracking-[0.2em] uppercase text-sm mb-10" style={{ color: C.sage }}>Blended Reflection + Cheat Sheet</p>

          <div className="mb-8 p-6 rounded-3xl text-[17px] shadow-sm border-[3px] flex-shrink-0" style={{ borderColor: C.goldLight, backgroundColor: '#fafafa' }}>
            <p className="font-medium leading-snug"><span className="font-black text-sm uppercase tracking-widest" style={{ color: C.sage }}>Instructions: </span>This exercise has two parts. First, figure out what&apos;s actually blocking you. Then, match it to a strategy that targets that specific blocker. Not every strategy works for every block. The goal is to build YOUR personalized cheat sheet.</p>
          </div>

          <div className="bg-white rounded-2xl p-5 border-2 shadow-sm mb-8" style={{ borderColor: '#e2dec9' }}>
            <p className="font-bold text-[15px] mb-1" style={{ color: C.charcoal }}>Part 1: My Initiation Blockers</p>
            <p className="text-[13px] mb-4 text-gray-500">Think about the last few times you couldn&apos;t start something. What was actually going on? Check the ones you recognize:</p>

            <div className="grid grid-cols-2 gap-y-3 gap-x-6">
              {[
                "The task felt too big or overwhelming",
                "I didn\u2019t know what the first step was",
                "I was afraid of doing it wrong",
                "It was boring and my brain refused to engage",
                "I couldn\u2019t transition from what I was already doing",
                "I was physically in the wrong place (couch, bed, etc.)",
                "I felt like I needed to be \u2018in the mood\u2019 to start",
                "I was already tired and had nothing left",
                "I was avoiding the feelings the task brings up (dread, shame, anxiety)"
              ].map((text, i) => (
                <div key={i} className="flex items-center gap-2">
                  <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="15" y="15" width="70" height="70" rx="8" />
                  </svg>
                  <span className="text-[13px] text-gray-700">{text}</span>
                </div>
              ))}
              {[1].map(i => (
                <div key={`blank-${i}`} className="flex items-center gap-2">
                  <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="15" y="15" width="70" height="70" rx="8" />
                  </svg>
                  <div className="flex-grow border-b-[2px] border-dotted mt-3" style={{ borderColor: '#e2dec9' }}></div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-2xl p-5 border-2 shadow-sm mb-8 flex-shrink-0" style={{ borderColor: C.goldLight }}>
            <p className="font-bold text-[15px] mb-6" style={{ color: C.sage }}>My top 3 blockers (the ones that show up most):</p>
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-end gap-3 w-full">
                  <span className={`${radley.className} font-bold text-2xl mb-[-4px]`} style={{ color: C.sage }}>{i}.</span>
                  <div className="flex-grow border-b-[2px] border-dotted mt-3" style={{ borderColor: '#e2dec9' }}></div>
                </div>
              ))}
            </div>
          </div>

          <p className="font-bold text-2xl mb-6">Part 2: My Starting Strategies</p>
          <p className="text-[15px] mb-6 text-gray-600">For each category below, check the strategies that target your blockers. Star your top 3–5 to try this week.</p>

          <div className="space-y-4 flex-shrink-0 relative z-10">
            {([
              { title: "IF THE TASK FEELS TOO BIG", items: [
                "Shrink it. What\u2019s the smallest first step? \u2018Open the laptop.\u2019 \u2018Pick up the pen.\u2019 \u2018Stand up.\u2019",
                "Set a timer for 5 minutes. You only have to do 5 minutes.",
              ]},
              { title: "IF IT\u2019S BORING AND YOUR BRAIN WON\u2019T ENGAGE", items: [
                "Stack it with something you actually enjoy (see your Bribe Menu from Chapter 2)",
                "Add a challenge. \u2018How fast can I do this?\u2019 Change your environment.",
              ]},
              { title: "IF YOU CAN\u2019T TRANSITION", items: [
                "Stand up. Physically move. Transition your body before your brain.",
                "Use a \u2018bridge\u2019 ritual. Count down from 5, then move. Don\u2019t think. Just go.",
              ]},
              { title: "IF YOU\u2019RE AFRAID OF DOING IT BADLY", items: [
                "Give yourself permission to do a terrible version. The bar is the floor.",
                "Done badly still beats not done at all. Every time.",
              ]},
              { title: "IF YOU\u2019RE AVOIDING THE FEELINGS IT BRINGS UP", items: [
                "Name the feeling out loud. \u2018I\u2019m avoiding this because it makes me feel ___.\u2019",
                "Visit Chapter 7 if the shame spiral is the real issue.",
              ]},
            ] as { title: string; items: string[] }[]).map((section, idx) => (
              <div key={idx} className="bg-white rounded-2xl p-5 border-2 shadow-sm" style={{ borderColor: '#e2dec9' }}>
                <p className={`${radley.className} font-bold text-[16px] uppercase tracking-widest mb-3`} style={{ color: C.sage }}>{section.title}</p>
                <div className="space-y-2">
                  {[...section.items, ""].map((item, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round">
                        <rect x="15" y="15" width="70" height="70" rx="8" />
                      </svg>
                      {item ? (
                        <p className="text-[14px] leading-snug" style={{ color: C.charcoal }}>{item}</p>
                      ) : (
                        <div className="flex-grow border-b-[2px] border-dotted mt-3" style={{ borderColor: '#e2dec9' }}></div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* --- CHAPTER 4 WORKBOOK PAGE 2: The Task Shrinker --- */}
        <section className="worksheet-page min-h-[970px] relative px-20 pt-20 px-20 pt-12 flex flex-col pb-32" style={{ backgroundColor: '#ffffff' }}>
          <h1 className={`${caveat.className} text-[60px] text-center mb-2 leading-tight mt-10 drop-shadow-sm`} style={{ color: C.charcoal }}>
            The Task Shrinker
          </h1>
          <p className="text-center font-black tracking-[0.2em] uppercase text-sm mb-10" style={{ color: C.sage }}>Action Planning Template</p>

          <div className="mb-10 p-6 rounded-3xl text-[17px] shadow-sm border-[3px] flex-shrink-0" style={{ borderColor: C.goldLight, backgroundColor: '#fafafa' }}>
            <p className="font-medium leading-snug"><span className="font-black text-sm uppercase tracking-widest" style={{ color: C.sage }}>Instructions: </span>Take 5 tasks you&apos;ve been avoiding. For each one, break it down to the absolute smallest first step. I mean embarrassingly small. If your first step could be broken down further, break it down. The goal is a step so tiny your brain can&apos;t object to it.</p>
          </div>

          <table className="w-full border-collapse text-[14px] mb-8 flex-shrink-0">
            <thead>
              <tr style={{ backgroundColor: C.cream }}>
                <th className="text-left p-4 font-black uppercase tracking-wider text-[12px] border-b-2 rounded-tl-xl" style={{ color: C.sage, borderColor: '#e2dec9', width: '22%' }}>Task I&apos;m avoiding</th>
                <th className="text-left p-4 font-black uppercase tracking-wider text-[12px] border-b-2 border-l-2" style={{ color: C.sage, borderColor: '#e2dec9', width: '39%' }}>My brain says it&apos;s this big:</th>
                <th className="text-left p-4 font-black uppercase tracking-wider text-[12px] border-b-2 border-l-2 rounded-tr-xl" style={{ color: C.sage, borderColor: '#e2dec9', width: '39%' }}>The actual smallest first step:</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b" style={{ borderColor: '#e2dec9' }}>
                <td className="p-4 italic text-gray-400 text-[13px] align-top">Example: Do taxes</td>
                <td className="p-4 italic text-gray-400 text-[13px] align-top border-l-2" style={{ borderColor: '#e2dec9' }}>&ldquo;Organize all my financial documents and figure out what I owe&rdquo;</td>
                <td className="p-4 italic text-gray-400 text-[13px] align-top border-l-2" style={{ borderColor: '#e2dec9' }}>&ldquo;Find last year&apos;s tax folder on my computer&rdquo;</td>
              </tr>
              {[1,2,3,4,5].map(n => (
                <tr key={n} className="border-b" style={{ borderColor: '#e2dec9' }}>
                  <td className="p-4 align-top" style={{ height: '70px' }}>
                    <span className={`${radley.className} font-bold text-xl`} style={{ color: C.sage }}>{n}.</span>
                  </td>
                  <td className="p-4 align-top border-l-2" style={{ borderColor: '#e2dec9', height: '70px' }}></td>
                  <td className="p-4 align-top border-l-2" style={{ borderColor: '#e2dec9', height: '70px' }}></td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="bg-white rounded-2xl p-5 border-2 shadow-sm mb-8 flex-shrink-0" style={{ borderColor: C.sageLight }}>
            <p className="font-bold text-[15px] italic leading-relaxed" style={{ color: C.charcoal }}>
              <span style={{ color: C.sage }}>P.S.</span> If you actually did the smallest first step for even one of those tasks right now... That&apos;s initiation. You just tricked your brain into starting.
            </p>
          </div>

          <div className="mt-auto p-5 rounded-2xl text-center border-t-[4px]" style={{ backgroundColor: C.cream, borderColor: C.sage }}>
            <p className="text-[15px] font-medium leading-relaxed text-gray-700">
              You just built two tools you can come back to every time you&apos;re frozen. The blocker list tells you <strong>WHY</strong> you&apos;re stuck. The cheat sheet tells you <strong>WHAT</strong> to try. And the task shrinker gives you a way to make any task so small your brain runs out of excuses.
            </p>
          </div>
        </section>

        {/* --- PAGE 26: CHAPTER 5 TITLE --- */}
        <section className="chapter-title-page min-h-[970px] flex flex-col justify-center items-center text-center px-20 py-20" style={{ backgroundColor: C.cream }}>
          <h1 className={`${caveat.className} text-[110px] leading-none mb-10 tracking-wide drop-shadow-md`} style={{ color: C.charcoal }}>
            CHAPTER 5
          </h1>
          <h2 className={`${radley.className} text-[56px] italic drop-shadow-sm px-8 relative`} style={{ color: C.sage }}>
            Doing the Boring Stuff Without Dying
          </h2>
          <svg className="mt-12 w-48 h-12" viewBox="0 0 200 40" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M5 20 Q 50 5, 100 20 T 195 20" stroke={C.gold} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </section>

        {/* --- PAGE 27: CHAPTER 5 — THE BIT --- */}
        <section className="content-section min-h-[970px] relative px-20 pt-20 bg-white pb-32">
          <div className="space-y-4 text-[17px] leading-[1.6]">
            <h2 className={`${radley.className} text-[35px] mb-10 border-b-4 inline-block font-bold`} style={{ color: C.sage, borderColor: C.sage }}>THE BIT</h2>

            <p>I will cancel plans with people I love but somehow never cancel my subscription to a service I haven&apos;t used in 8 months. I will let mail pile up on my counter for weeks because opening it feels like a task that requires the emotional bandwidth I simply do not have. I once paid... sorry, I have paid MANY late fees on bills I had the money for, sitting in my account, ready to go, because paying them required logging into a website and I could not make myself do it.</p>

            <p>I&apos;m not irresponsible. I&apos;m just deeply, profoundly uninterested and unstimulated.</p>

            <div className="my-6 p-6 rounded-2xl shadow-sm border-l-[6px] inline-block" style={{ backgroundColor: C.goldLight, borderColor: C.gold }}>
              <p className="font-bold text-[22px] leading-snug" style={{ color: C.charcoal }}>
                I call this one the Boredom Blackout.
              </p>
            </div>

            <p>Lights off, nobody home, brain has left the building.</p>

            <p>And that&apos;s the thing nobody tells you about ADHD and boring tasks. It&apos;s not that you don&apos;t know they need to get done. You know. You know so well that the knowing is actually part of the problem, because now you&apos;re carrying around the weight of every undone boring thing alongside the guilt of not doing it. It&apos;s not a knowledge issue. It&apos;s a &ldquo;my brain has physically checked out of this conversation&rdquo; issue.</p>

            <h2 className={`${radley.className} text-[35px] mt-14 mb-8 border-b-4 inline-block font-bold`} style={{ color: C.sage, borderColor: C.sage }}>THE REAL TALK</h2>

            <p>If you read Chapter 2, you already know your brain runs on what Dr. William Dodson calls the interest-based nervous system. Quick recap: your brain is motivated by interest, novelty, challenge, urgency, and passion — not by importance, consequences, or rewards that are far away. If a task doesn&apos;t hit at least one of those, your brain doesn&apos;t produce the engagement it needs to get going.</p>

            <p>So what happens when the task is paying a bill? Filing taxes? Responding to that email that&apos;s been sitting in your inbox for 11 days? None of those things are interesting, novel, challenging, urgent (yet), or passion-inducing. They&apos;re just... necessary. And your brain does not care about necessary.</p>
          </div>
        </section>

        {/* --- PAGE 28: CHAPTER 5 — REAL TALK CONT. --- */}
        <section className="content-section min-h-[970px] relative px-20 pt-20 pb-32" style={{ backgroundColor: C.cream }}>
          <div className="space-y-4 text-[17px] leading-[1.6]">

            <p>A neuroimaging study looked at this directly. Researchers found that adults with ADHD scored significantly lower on a trait measure of motivation than adults without ADHD. They traced this back to the dopamine reward system in the brain — the part that&apos;s supposed to light up and say &ldquo;yes, let&apos;s do this.&rdquo; In adults with ADHD, that system was less active. The researchers concluded that this is likely why people with ADHD have such a hard time engaging with tasks that aren&apos;t inherently rewarding or stimulating <span className="uppercase text-xs opacity-60 tracking-wider font-bold">(Volkow et al., 2011)</span>. In other words, it&apos;s not that you&apos;re choosing not to care about boring tasks. Your brain&apos;s reward system is literally producing less of the signal it needs to engage with them.</p>

            <div className="my-8 p-6 rounded-2xl shadow-sm border-l-[6px]" style={{ backgroundColor: '#ffffff', borderColor: C.gold }}>
              <p className="font-bold text-[20px] leading-snug" style={{ color: C.charcoal }}>
                And now cue the shame. You know the task is important. Other people seem to just... do these things. And you&apos;re sitting there unable to make yourself open an envelope. It feels like a personal failing. It&apos;s not.
              </p>
            </div>

            <p>It&apos;s your brain&apos;s reward system not responding to a task that doesn&apos;t offer it enough stimulation. That&apos;s a completely different problem than not caring, and it has a completely different set of solutions.</p>

            <p className="font-bold px-6 py-5 rounded-xl shadow-sm" style={{ backgroundColor: '#ebf2ed', color: C.charcoal }}>
              The manipulation isn&apos;t about forcing yourself to care about boring tasks. You won&apos;t. Your brain doesn&apos;t work that way. The manipulation is about adding something to the task, or to the environment around the task, that gives your brain the stimulation it actually needs to show up.
            </p>

            <h2 className={`${radley.className} text-[35px] mt-14 mb-8 border-b-4 inline-block font-bold`} style={{ color: C.sage, borderColor: C.sage }}>THE MANIPULATION</h2>

            <p>You already have tools for this from earlier in the workbook. Your Bribe Menu from Chapter 2 is designed for exactly this. The environment strategies from Chapter 3 apply here too. This chapter is about putting those tools to work on the specific category of tasks that ADHD brains hate the most: the boring, repetitive, low-stimulation stuff that makes up a surprising amount of adult life.</p>

            <p>Here&apos;s the approach I use with my clients. You&apos;re not going to suddenly enjoy doing your taxes. But you CAN make the experience of doing your taxes less miserable by changing what surrounds it.</p>

          </div>
        </section>

        {/* --- PAGE 29: CHAPTER 5 — THE MANIPULATION CONT. --- */}
        <section className="content-section min-h-[970px] relative px-20 pt-20 bg-white pb-32">
          <div className="space-y-4 text-[17px] leading-[1.6]">


            {([
              { title: "Pair it.", body: "Attach something you enjoy to the task. Podcast plus cleaning. Music plus admin work. A fancy drink plus email. You\u2019re not rewarding yourself after. You\u2019re making the task tolerable during." },
              { title: "Move it.", body: "Change where you do it. Boring tasks at a coffee shop feel different than boring tasks on your couch. A new environment adds novelty, which is one of the things your brain actually responds to. It also breaks the association your brain has between certain spaces and certain energy levels. If you always do nothing on the couch, your brain will keep doing nothing on the couch. Go somewhere else." },
              { title: "Shrink it.", body: "You don\u2019t have to do all of it. You have to do 10 minutes of it. Set a timer, do 10 minutes, and then decide if you want to keep going. Most of the time, once you\u2019re in it, you\u2019ll keep going. And if you don\u2019t? You did 10 minutes more than you did yesterday." },
              { title: "Automate or delegate it.", body: "Some boring tasks don\u2019t need to be done by you at all. Auto-pay bills. Set up recurring grocery orders. Put subscriptions on auto-renew (or auto-cancel, depending on the subscription). And if a task can\u2019t be automated, ask yourself: can someone else do this? Every boring task you can hand off to a system or another person is one less thing draining your limited energy." },
              { title: "Make it urgent.", body: "Your brain responds to urgency even when it doesn\u2019t respond to importance. Tell someone you\u2019ll have it done by 3pm. Set a deadline that matters. Create consequences that are immediate, not hypothetical." },
            ] as { title: string; body: string }[]).map((item, i) => (
              <div key={i} className="p-5 rounded-2xl border-2 shadow-sm" style={{ borderColor: '#e2dec9', backgroundColor: '#fafafa' }}>
                <p className="font-black text-[18px]" style={{ color: C.sage }}>{item.title}</p>
                <p className="text-[17px] leading-relaxed text-gray-700">{item.body}</p>
              </div>
            ))}

          </div>
        </section>

        
        {/* Transition bridge — bottom of preceding content, NOT standalone */}
        <div className="mt-16 text-center pb-10 content-section">
<span className={`${caveat.className} text-[60px]`} style={{ color: C.gold }}>Alright, let&apos;s deal with it.</span>
          <span className="animate-bounce mt-6 text-6xl" style={{ color: C.sage }}>↓</span>
          <p className="text-center italic text-[20px] text-[#6B6B6B] max-w-2xl mx-auto leading-relaxed mt-8">
            Two exercises for this chapter, plus a bonus. The first gets everything out of your head. The second gives you a plan for each task. The bonus sets up a weekly system so the boring stuff stops piling up forever.
          </p>
        </div>


        {/* --- PAGE 29: CHAPTER 5 WORKBOOK PAGE 1 — Boring Task Graveyard --- */}
        <section className="worksheet-page min-h-[970px] relative px-20 pt-20 px-20 pt-12 flex flex-col pb-32" style={{ backgroundColor: '#ffffff' }}>
          <h1 className={`${caveat.className} text-[60px] text-center mb-2 leading-tight mt-10 drop-shadow-sm`} style={{ color: C.charcoal }}>
            My Boring Task Graveyard
          </h1>
          <p className="text-center font-black tracking-[0.2em] uppercase text-sm mb-10" style={{ color: C.sage }}>Brain Dump</p>

          <div className="mb-8 p-6 rounded-3xl text-[17px] shadow-sm border-[3px] flex-shrink-0" style={{ borderColor: C.goldLight, backgroundColor: '#fafafa' }}>
            <p className="font-medium leading-snug"><span className="font-black text-sm uppercase tracking-widest" style={{ color: C.sage }}>Instructions: </span>This is every boring task you&apos;re currently avoiding. All of them. Big ones, small ones, the ones that have been on your list so long they&apos;ve become background noise. Don&apos;t filter, don&apos;t judge, don&apos;t organize. Just get them out of your head and onto this page.</p>
          </div>

          <p className="font-bold text-2xl mb-8">What are all the boring tasks I&apos;m currently avoiding?</p>

          <div className="flex-grow rounded-2xl border-2 mt-2" style={{ borderColor: '#e2dec9' }}></div>
        </section>

        {/* --- PAGE 30: CHAPTER 5 WORKBOOK PAGE 2 — Boring Task Battle Plan --- */}
        <section className="worksheet-page min-h-[970px] relative px-20 pt-20 px-20 pt-12 flex flex-col pb-32" style={{ backgroundColor: '#ffffff' }}>
          <h1 className={`${caveat.className} text-[60px] text-center mb-2 leading-tight mt-10 drop-shadow-sm`} style={{ color: C.charcoal }}>
            The Boring Task Battle Plan
          </h1>
          <p className="text-center font-black tracking-[0.2em] uppercase text-sm mb-8" style={{ color: C.sage }}>Action Planning Template</p>

          <div className="mb-6 p-6 rounded-3xl text-[17px] shadow-sm border-[3px] flex-shrink-0" style={{ borderColor: C.goldLight, backgroundColor: '#fafafa' }}>
            <p className="font-medium leading-snug"><span className="font-black text-sm uppercase tracking-widest" style={{ color: C.sage }}>Instructions: </span>Pick 5 tasks from the Graveyard. For each one, assign a strategy: pair it, move it, shrink it, or automate/delegate it. Some tasks might get more than one.</p>
          </div>

          <table className="w-full border-collapse text-[13px] mb-6 flex-shrink-0">
            <thead>
              <tr style={{ backgroundColor: C.cream }}>
                <th className="text-left p-3 font-black uppercase tracking-wider text-[11px] border-b-2 rounded-tl-xl" style={{ color: C.sage, borderColor: '#e2dec9', width: '18%' }}>Task</th>
                <th className="text-left p-3 font-black uppercase tracking-wider text-[11px] border-b-2 border-l-2" style={{ color: C.sage, borderColor: '#e2dec9', width: '22%' }}>Pair it <span className="font-normal normal-case opacity-60 text-[10px]">(listen/drink/do alongside?)</span></th>
                <th className="text-left p-3 font-black uppercase tracking-wider text-[11px] border-b-2 border-l-2" style={{ color: C.sage, borderColor: '#e2dec9', width: '20%' }}>Move it <span className="font-normal normal-case opacity-60 text-[10px]">(where?)</span></th>
                <th className="text-left p-3 font-black uppercase tracking-wider text-[11px] border-b-2 border-l-2" style={{ color: C.sage, borderColor: '#e2dec9', width: '20%' }}>Shrink it <span className="font-normal normal-case opacity-60 text-[10px]">(how long?)</span></th>
                <th className="text-left p-3 font-black uppercase tracking-wider text-[11px] border-b-2 border-l-2 rounded-tr-xl" style={{ color: C.sage, borderColor: '#e2dec9', width: '20%' }}>Automate / Delegate <span className="font-normal normal-case opacity-60 text-[10px]">(who or what?)</span></th>
              </tr>
            </thead>
            <tbody>
              {[1,2,3,4,5].map(n => (
                <tr key={n} className="border-b" style={{ borderColor: '#e2dec9' }}>
                  <td className="p-3 align-top" style={{ height: '80px' }}>
                    <span className={`${radley.className} font-bold text-lg`} style={{ color: C.sage }}>{n}.</span>
                  </td>
                  <td className="p-3 align-top border-l-2" style={{ borderColor: '#e2dec9' }}></td>
                  <td className="p-3 align-top border-l-2" style={{ borderColor: '#e2dec9' }}></td>
                  <td className="p-3 align-top border-l-2" style={{ borderColor: '#e2dec9' }}></td>
                  <td className="p-3 align-top border-l-2" style={{ borderColor: '#e2dec9' }}></td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="bg-white rounded-2xl p-5 border-2 shadow-sm mb-5 flex-shrink-0" style={{ borderColor: C.goldLight }}>
            <div className="space-y-4">
              {["Which one am I doing first?", "When?"].map((label, i) => (
                <div key={i} className="flex items-end gap-3 w-full">
                  <span className="font-bold text-[13px] flex-shrink-0 mb-[-2px] uppercase tracking-widest text-[#6B6B6B]">{label}</span>
                  <div className="flex-grow border-b-[2px] border-dotted mt-3" style={{ borderColor: '#e2dec9' }}></div>
                </div>
              ))}
              <div className="flex items-end gap-3 w-full">
                <span className="font-bold text-[13px] flex-shrink-0 mb-[-2px] uppercase tracking-widest text-[#6B6B6B]">What&apos;s my bribe? <span className="text-[10px] font-normal normal-case tracking-normal">(check your Bribe Menu from Chapter 2)</span></span>
                <div className="flex-grow border-b-[2px] border-dotted mt-3" style={{ borderColor: '#e2dec9' }}></div>
              </div>
            </div>
          </div>

          <div className="px-6 py-4 rounded-xl flex-shrink-0" style={{ backgroundColor: '#ebf2ed' }}>
            <p className="italic text-[14px] font-medium leading-snug" style={{ color: C.charcoal }}>
              <span className="font-bold">P.S.</span> If you filled this out and then actually did one of those tasks? You just beat a boring task. Add it to your wins.
            </p>
          </div>
        </section>

        {/* --- PAGE 31: CHAPTER 5 BONUS — My Agony Hour Blueprint --- */}
        <section className="worksheet-page min-h-[970px] relative px-20 pt-20 px-20 pt-12 flex flex-col pb-32" style={{ backgroundColor: '#ffffff' }}>
          <div className="flex items-center gap-3 mt-10 mb-2">
            <span className="text-xs font-black uppercase tracking-[0.2em]" style={{ color: C.gold }}>Bonus</span>
            <div className="flex-grow border-t-2" style={{ borderColor: C.goldLight }}></div>
          </div>
          <h1 className={`${caveat.className} text-[60px] text-center mb-2 leading-tight drop-shadow-sm`} style={{ color: C.charcoal }}>
            My Agony Hour Blueprint
          </h1>
          <p className="text-center font-black tracking-[0.2em] uppercase text-sm mb-8" style={{ color: C.sage }}>Weekly Planner</p>

          <div className="mb-5 p-6 rounded-3xl text-[17px] shadow-sm border-[3px] flex-shrink-0" style={{ borderColor: C.goldLight, backgroundColor: '#fafafa' }}>
            <p className="font-medium leading-snug"><span className="font-black text-sm uppercase tracking-widest" style={{ color: C.sage }}>Instructions: </span>Instead of letting boring tasks pile up until they become a crisis, batch them into one dedicated hour each week. Pick a day, a time, and a place. Bring your Bribe Menu. Make it a ritual, not a punishment. If a full hour feels like too much, start with 30 minutes.</p>
          </div>

          <div className="px-6 py-4 rounded-xl mb-5 flex-shrink-0" style={{ backgroundColor: '#ebf2ed' }}>
            <p className="italic text-[14px] font-medium leading-snug" style={{ color: C.charcoal }}>
              <span className="font-bold">Why &ldquo;The Agony Hour&rdquo;? </span>Because we&apos;re not lying to ourselves here. Unfun tasks are sometimes just going to suck. Bribes can make them tolerable, but they&apos;re not going to make filing your taxes feel like a spa day. I always find it better to be honest with yourself so you can set realistic expectations instead of pretending you&apos;re going to enjoy it and then feeling worse when you don&apos;t.
            </p>
          </div>

          <div className="bg-white rounded-2xl p-5 border-2 shadow-sm mb-5" style={{ borderColor: C.goldLight }}>
            <p className="font-bold text-[15px] mb-4" style={{ color: C.sage }}>My Agony Hour:</p>
            <div className="space-y-4">
              {["Day:", "Time:", "Where:"].map((label, i) => (
                <div key={i} className="flex items-end gap-3 w-full">
                  <span className="font-bold text-[13px] flex-shrink-0 mb-[-2px] uppercase tracking-widest text-[#6B6B6B]">{label}</span>
                  <div className="flex-grow border-b-[2px] border-dotted mt-3" style={{ borderColor: '#e2dec9' }}></div>
                </div>
              ))}
              <div className="flex items-end gap-3 w-full">
                <span className="font-bold text-[13px] flex-shrink-0 mb-[-2px] uppercase tracking-widest text-[#6B6B6B]">My bribes <span className="text-[10px] font-normal normal-case tracking-normal">(drink, snack, music, podcast — whatever it takes):</span></span>
                <div className="flex-grow border-b-[2px] border-dotted mt-3" style={{ borderColor: '#e2dec9' }}></div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-5 border-2 shadow-sm mb-5" style={{ borderColor: '#e2dec9' }}>
            <p className="font-bold text-[15px] mb-4" style={{ color: C.sage }}>My Agony Hour task list for this week:</p>
            <div className="grid grid-cols-2 gap-y-3 gap-x-6 mb-5">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="flex items-center gap-2">
                  <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="15" y="15" width="70" height="70" rx="8" />
                  </svg>
                  <div className="flex-grow border-b-[2px] border-dotted mt-3" style={{ borderColor: '#e2dec9' }}></div>
                </div>
              ))}
            </div>
            <div className="flex items-end gap-3 w-full">
              <span className="font-bold text-[13px] flex-shrink-0 mb-[-2px] uppercase tracking-widest text-[#6B6B6B]">My reward right after:</span>
              <div className="flex-grow border-b-[2px] border-dotted mt-3" style={{ borderColor: '#e2dec9' }}></div>
            </div>
            <p className="text-[12px] italic text-gray-400 mt-2">(And yes, the reward can just be the pure satisfaction of having done it. Permission to gloat to absolutely anyone and everyone is fully granted.)</p>
          </div>

          <div className="px-6 py-4 rounded-xl mb-5 flex-shrink-0" style={{ backgroundColor: '#ebf2ed' }}>
            <p className="italic text-[14px] font-medium leading-snug" style={{ color: C.charcoal }}>
              <span className="font-bold">P.S.</span> If you promised yourself a chocolate bar after but ate it before you finished the task and then didn&apos;t finish the task... we are not accepting shame for this. Absolutely not. But we ARE taking it as data. Check your Bribe Menu from Chapter 2 and set yourself up differently next time.
            </p>
          </div>

          <div className="mt-auto p-5 rounded-2xl text-center border-t-[4px]" style={{ backgroundColor: C.cream, borderColor: C.sage }}>
            <p className="text-[15px] font-medium leading-relaxed text-gray-700">
              You just took the most annoying category of tasks in your life and built a plan for dealing with them. Not by caring more. Not by trying harder. By working with your brain instead of yelling at it. Next up: what to do when your brain won&apos;t stop replaying a conversation you had in 2014 — and won&apos;t let you move on until it&apos;s dissected every word.
            </p>
          </div>
        </section>
        {/* =========================================================== */}
        {/* CHAPTER 6 */}
        {/* =========================================================== */}

        {/* --- PAGE 32: CHAPTER 6 TITLE --- */}
        <section className="chapter-title-page min-h-[970px] flex flex-col justify-center items-center text-center px-20 py-20" style={{ backgroundColor: C.cream }}>
          <h1 className={`${caveat.className} text-[110px] leading-none mb-10 tracking-wide drop-shadow-md`} style={{ color: C.charcoal }}>
            CHAPTER 6
          </h1>
          <h2 className={`${radley.className} text-[56px] italic drop-shadow-sm px-8 relative`} style={{ color: C.sage }}>
            When My Brain Won&apos;t Shut Up
          </h2>
          <svg className="mt-12 w-48 h-12" viewBox="0 0 200 40" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M5 20 Q 50 5, 100 20 T 195 20" stroke={C.gold} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </section>

        {/* --- PAGE 33: CHAPTER 6 — THE BIT --- */}
        <section className="content-section min-h-[970px] relative px-20 pt-20 bg-white pb-32">
          <div className="space-y-4 text-[17px] leading-[1.6]">
            <h2 className={`${radley.className} text-[35px] mb-8 border-b-4 inline-block font-bold`} style={{ color: C.sage, borderColor: C.sage }}>THE BIT</h2>

            <p>You know when you sit down to do something and your brain immediately goes, &ldquo;Hey, before we start, let&apos;s think about that weird thing your coworker said last Tuesday. Also, did you ever reply to that text? Also, you should really call your dentist. Also, remember that embarrassing thing from 2013? Let&apos;s analyze that real quick.&rdquo;</p>

            <p>And then 40 minutes have passed and you haven&apos;t started the thing. You haven&apos;t done anything, actually. You&apos;ve just been sitting there while your brain held an all-staff meeting you didn&apos;t call.</p>

            <div className="my-4 p-6 rounded-2xl shadow-sm border-l-[6px] inline-block" style={{ backgroundColor: C.goldLight, borderColor: C.gold }}>
              <p className="font-bold text-[21px] leading-snug" style={{ color: C.charcoal }}>
                I call this one the Overthinking Looper.
              </p>
            </div>

            <p>Not something you&apos;ll find in any textbook — just the most accurate name I have for when your brain keeps looping through the same thoughts like a song stuck on repeat, except the song is anxiety and it never gets to the chorus.</p>

            <p>This happens in the shower. On the couch. In the middle of a conversation. At 2am when you&apos;re trying to sleep. It&apos;s not limited to one time or place. It&apos;s just... constant. Your brain performing a one-person show to an audience of one, about topics you did not choose, at times you did not request. Kinda rude if you ask me.</p>

            <p>And here&apos;s why this chapter is in a book called &ldquo;Manipulating Myself to Do Stuff&rdquo;: because you can&apos;t manipulate yourself into doing anything when your brain is off delivering a full presentation covering everything you did wrong this week, everything you need to do, and maybe a few random funny memories thrown in for variety. Mental clutter isn&apos;t just annoying. It makes it genuinely harder to start things, make decisions, and follow through on plans. When your head is full, there&apos;s no room left for action.</p>

            <p className="font-bold px-6 py-5 rounded-xl shadow-sm" style={{ backgroundColor: '#ebf2ed', color: C.charcoal }}>
              This chapter is about clearing the runway so you can take off.
            </p>
          </div>
        </section>

        {/* --- PAGE 34: CHAPTER 6 — THE REAL TALK --- */}
        <section className="content-section min-h-[970px] relative px-20 pt-20 pb-32" style={{ backgroundColor: C.cream }}>
          <div className="space-y-4 text-[17px] leading-[1.6]">
            <h2 className={`${radley.className} text-[35px] mb-8 border-b-4 inline-block font-bold`} style={{ color: C.sage, borderColor: C.sage }}>THE REAL TALK</h2>

            <p>So why does your brain do this? Why can&apos;t it just... stop?</p>

            <p>There&apos;s actually a brain network responsible for a lot of this. It&apos;s called the <strong>default mode network</strong>, or DMN — a set of brain regions that activate when you&apos;re not focused on a specific task. Dr. Edward Hallowell, a psychiatrist who specializes in ADHD (and has it himself), calls it &ldquo;the demon of ADHD.&rdquo; It&apos;s what runs when you&apos;re daydreaming, replaying memories, or thinking about the future. Everyone has one.</p>

            <p>Your brain also has a <strong>task-positive network</strong>, or TPN, which is the network that lights up when you&apos;re actually doing something. In most people&apos;s brains, these two networks work like a seesaw: when one goes up, the other goes down. You&apos;re either doing or daydreaming, but not both at the same time.</p>

            <div className="my-4 p-6 rounded-2xl shadow-sm border-l-[6px]" style={{ backgroundColor: '#ffffff', borderColor: C.gold }}>
              <p className="font-bold text-[19px] leading-snug" style={{ color: C.charcoal }}>
                In ADHD 2.0, Hallowell and Dr. John Ratey describe what they call &ldquo;the glitchy switch.&rdquo; In ADHD, that seesaw doesn&apos;t work properly. When the TPN turns on, the DMN stays on too, competing for your attention instead of stepping aside. They describe it as the DMN trying to muscle its way in and pull you into its grasp, even when you&apos;re trying to focus on a task <span className="uppercase text-xs opacity-60 tracking-wider font-bold">(Hallowell & Ratey, 2021, pp. 24–26)</span>.
              </p>
            </div>

            <p>So when you&apos;re replaying a conversation from six years ago while simultaneously planning tomorrow and worrying about something you forgot to do last week — at your desk, in the shower, or at 2am — that&apos;s not you being dramatic. That&apos;s your DMN running the show because the part of your brain that&apos;s supposed to tell it to quiet down isn&apos;t doing its job.</p>

            <p>Here&apos;s the part most people miss: a lot of folks with ADHD don&apos;t realize this is an ADHD thing at all. They think they&apos;re just &ldquo;an overthinker&rdquo; or &ldquo;an anxious person.&rdquo; And sometimes those things are true too. But the constant mental chatter, the inability to sit in silence without your brain filling it with noise, the way your thoughts jump from topic to topic without any input from you? For a lot of ADHDers, that&apos;s the glitchy switch in action. Once you understand that, you can stop trying to think your way out of it and start working with your wiring instead of against it.</p>

            <p className="font-bold px-6 py-5 rounded-xl shadow-sm" style={{ backgroundColor: '#ebf2ed', color: C.charcoal }}>
              The manipulation here isn&apos;t really about stopping the thoughts. It&apos;s about giving them somewhere to go so they stop circling inside your head.
            </p>
          </div>
        </section>

        {/* --- PAGE 35: CHAPTER 6 — THE MANIPULATION --- */}
        <section className="content-section min-h-[970px] relative px-20 pt-20 bg-white pb-32">
          <div className="space-y-4 text-[17px] leading-[1.6]">
            <h2 className={`${radley.className} text-[35px] mb-8 border-b-4 inline-block font-bold`} style={{ color: C.sage, borderColor: C.sage }}>THE MANIPULATION</h2>

            <p>So your DMN is running the show and you need to get back to actually doing things. Thinking your way out of a thought loop is hard. So let&apos;s interrupt it instead. Here&apos;s some ways you can do that.</p>

            <div className="p-4 rounded-2xl border-2 shadow-sm" style={{ borderColor: '#e2dec9', backgroundColor: '#fafafa' }}>
              <p className="font-black text-[17px]" style={{ color: C.sage }}>Dump it out.</p>
              <p className="text-[16px] leading-relaxed text-gray-700">Grab a piece of paper and write down everything in your head. Not organized. Not categorized. Not neat. Just... out. The more you try to hold information in your head, the louder it gets. Get it on paper and your brain can stop recycling it. Then sort what you wrote: some of it is tasks, some of it is feelings, some of it is stuff you can let go of entirely.</p>
            </div>
            <div className="p-4 rounded-2xl border-2 shadow-sm" style={{ borderColor: '#e2dec9', backgroundColor: '#fafafa' }}>
              <p className="font-black text-[17px]" style={{ color: C.sage }}>Park it and move on.</p>
              <p className="text-[16px] leading-relaxed text-gray-700">Keep a notepad next to you while you work. When a random thought pops up, jot it down and get back to what you were doing. You&apos;re not ignoring the thought. You&apos;re parking it so your brain can let go of it for now.</p>
            </div>
            <div className="p-4 rounded-2xl border-2 shadow-sm" style={{ borderColor: '#e2dec9', backgroundColor: '#fafafa' }}>
              <p className="font-black text-[17px]" style={{ color: C.sage }}>Move your body.</p>
              <p className="text-[16px] leading-relaxed text-gray-700">A study found that even a single bout of moderate exercise reduced rumination in participants <span className="uppercase text-xs opacity-60 tracking-wider font-bold">(Brand et al., 2018)</span>. A walk, some stretching, even just getting up and changing rooms. You&apos;re not outrunning the thoughts. You&apos;re giving your brain something physical to focus on instead.</p>
            </div>
            <div className="p-4 rounded-2xl border-2 shadow-sm" style={{ borderColor: '#e2dec9', backgroundColor: '#fafafa' }}>
              <p className="font-black text-[17px]" style={{ color: C.sage }}>Name what’s going on.</p>
              <p className="text-[16px] leading-relaxed text-gray-700">When your brain is spiraling, try naming it. “I’m overthinking right now.” Studies have found that simply naming what you’re feeling can reduce the intensity of that emotional response <span className="uppercase text-xs opacity-60 tracking-wider font-bold">(Lieberman et al., 2011)</span>. It doesn’t make the spiral stop, but it shifts you from being inside it to noticing it.</p>
            </div>
            <div className="p-4 rounded-2xl border-2 shadow-sm" style={{ borderColor: '#e2dec9', backgroundColor: '#fafafa' }}>
              <p className="font-black text-[17px]" style={{ color: C.sage }}>Breathe in a pattern.</p>
              <p className="text-[16px] leading-relaxed text-gray-700">Focused breathing is one of the simplest ways to flip the glitchy switch back. Dr. Hallowell &amp; Dr. Ratey recommend giving your brain a small task to focus on &mdash; like inhaling for six beats, holding for three, exhaling for eight, holding for three, and repeating. A few cycles of this and you’ve nudged your brain back into the task-positive network <span className="uppercase text-xs opacity-60 tracking-wider font-bold">(Hallowell &amp; Ratey, 2021)</span>.</p>
            </div>

            <p className="text-[17px]">Any one of these can break the loop. You don&apos;t need all five. You need the one that works for you in the moment.</p>

            <div className="mt-2 px-6 py-5 rounded-xl shadow-sm italic text-[16px]" style={{ backgroundColor: '#ebf2ed', color: C.charcoal }}>
              <strong>One more thing.</strong>{' '}If the overthinking feels like more than a nuisance — if it&apos;s constant, if it&apos;s keeping you from sleeping or functioning, if it feels like it&apos;s running your life — that&apos;s worth talking to someone about. A therapist who understands ADHD can help you untangle what&apos;s brain wiring and what might need more support than a workbook can give you. This book is a starting point, not a ceiling.
            </div>
          </div>
        </section>

        {/* --- PAGE 36: CHAPTER 6 — CLOSE / LET'S GET TO IT --- */}
        <section className="content-section min-h-[970px] relative px-20 pt-20 flex flex-col justify-center items-center text-center pb-32" style={{ backgroundColor: C.cream }}>
          <span className={`${caveat.className} text-[60px]`} style={{ color: C.gold }}>Let&apos;s get to it.</span>
          <span className="animate-bounce mt-6 text-6xl" style={{ color: C.sage }}>↓</span>
          <p className="text-center italic text-[20px] text-[#6B6B6B] max-w-2xl mx-auto leading-relaxed mt-8">
            Two exercises for this chapter. The first clears everything out of your head and helps you sort it. The second maps your overthinking patterns so you can interrupt them before they take over.
          </p>
        </section>

        {/* --- PAGE 37: CH6 WORKBOOK PAGE 1a — THE DUMP --- */}
        <section className="worksheet-page min-h-[970px] relative px-20 pt-20 px-20 pt-12 flex flex-col bg-white pb-32">
          <h1 className={`${caveat.className} text-[55px] text-center mb-2 leading-tight mt-10 drop-shadow-sm`} style={{ color: C.charcoal }}>
            The Big Brain Dump + The Sort
          </h1>
          <p className="text-center font-black tracking-[0.2em] uppercase text-sm mb-8" style={{ color: C.sage }}>Brain Dump + Action Planning</p>

          <div className="mb-6 p-5 rounded-3xl text-[16px] shadow-sm border-[3px] flex-shrink-0" style={{ borderColor: C.goldLight, backgroundColor: '#fafafa' }}>
            <p className="font-medium leading-snug"><span className="font-black text-sm uppercase tracking-widest" style={{ color: C.sage }}>Instructions: </span>This exercise has two parts. First, dump. Then sort. Do the dump all at once. Do the sort after, when you&apos;re ready.</p>
          </div>

          <p className="font-black uppercase tracking-[0.15em] text-sm mb-4" style={{ color: C.sage }}>Part 1: The Dump</p>
          <p className="text-[16px] text-gray-600 mb-4">Write down everything that&apos;s in your head right now. Every thought, worry, task, idea, feeling, random fragment. No categories. No order. No judgment. Fill the whole thing if you need.</p>

          <div className="flex-grow rounded-2xl border-2 mt-2" style={{ borderColor: '#e2dec9' }}></div>
        </section>

        {/* --- PAGE 38: CH6 WORKBOOK PAGE 1b — THE SORT --- */}
        <section className="content-section min-h-[970px] relative px-20 pt-20 px-20 pt-12 flex flex-col pb-32" style={{ backgroundColor: C.cream }}>
          <p className="font-black uppercase tracking-[0.15em] text-sm mb-6 mt-10" style={{ color: C.sage }}>Part 2: The Sort</p>
          <p className="text-[17px] text-gray-700 mb-8">Now go back through your dump and sort each item into one of these four buckets. You can use letters (A, B, C, D) next to each item, or rewrite them below.</p>

          <div className="grid grid-cols-2 gap-6 mb-8">
            {([
              { letter: "A", label: "Things I can act on NOW", sub: "this week, concrete next step exists" },
              { letter: "B", label: "Things I can act on LATER", sub: "not urgent, but real — needs a date or reminder" },
              { letter: "C", label: "Things that are just feelings", sub: "not a task, just something I\u2019m carrying" },
              { letter: "D", label: "Things I can let go of", sub: "not mine to solve, already done, or just noise" },
            ] as { letter: string; label: string; sub: string }[]).map((bucket) => (
              <div key={bucket.letter} className="bg-white rounded-2xl p-5 border-2 shadow-sm flex flex-col" style={{ borderColor: '#e2dec9', minHeight: '200px' }}>
                <div className="flex items-center gap-3 mb-3">
                  <span className={`${caveat.className} text-[40px] font-bold leading-none`} style={{ color: C.gold }}>{bucket.letter}.</span>
                  <div>
                    <p className="font-black text-[14px] uppercase tracking-wide leading-snug" style={{ color: C.sage }}>{bucket.label}</p>
                    <p className="text-[11px] text-gray-400 italic">{bucket.sub}</p>
                  </div>
                </div>
                <div className="flex-grow flex flex-col justify-end space-y-4">
                  <div className="border-b-[2px] border-dotted mt-7" style={{ borderColor: '#e2dec9' }}></div>
                  <div className="border-b-[2px] border-dotted mt-7" style={{ borderColor: '#e2dec9' }}></div>
                  <div className="border-b-[2px] border-dotted mt-7" style={{ borderColor: '#e2dec9' }}></div>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-2xl p-5 border-[3px] shadow-sm flex-shrink-0" style={{ borderColor: C.goldLight }}>
            <p className="font-bold text-[15px] mb-4" style={{ color: C.charcoal }}>How does your brain feel now compared to before the dump? Even a little lighter counts.</p>
            <div className="space-y-4">
              <div className="border-b-[2px] border-dotted mt-7" style={{ borderColor: '#e2dec9' }}></div>
              <div className="border-b-[2px] border-dotted mt-7" style={{ borderColor: '#e2dec9' }}></div>
            </div>
          </div>
        </section>

        {/* --- PAGE 39: CH6 WORKBOOK PAGE 2a — SPOT THE PATTERN --- */}
        <section className="worksheet-page min-h-[970px] relative px-20 pt-20 px-20 pt-12 flex flex-col bg-white pb-32">
          <h1 className={`${caveat.className} text-[52px] text-center mb-2 leading-tight mt-10 drop-shadow-sm`} style={{ color: C.charcoal }}>
            My Overthinking Patterns + My Interrupt Plan
          </h1>
          <p className="text-center font-black tracking-[0.2em] uppercase text-sm mb-6" style={{ color: C.sage }}>Reflection + Action Planning</p>

          <div className="mb-6 p-5 rounded-3xl text-[16px] shadow-sm border-[3px] flex-shrink-0" style={{ borderColor: C.goldLight, backgroundColor: '#fafafa' }}>
            <p className="font-medium leading-snug"><span className="font-black text-sm uppercase tracking-widest" style={{ color: C.sage }}>Instructions: </span>Let&apos;s figure out when and where your brain tends to get the loudest. If you can spot your patterns, you can start to interrupt them earlier.</p>
          </div>

          <p className="font-black uppercase tracking-[0.15em] text-sm mb-5" style={{ color: C.sage }}>Part 1: Spot the Pattern</p>

          <div className="bg-white rounded-2xl p-5 border-2 shadow-sm mb-6" style={{ borderColor: '#e2dec9' }}>
            <p className="font-bold text-[15px] mb-3" style={{ color: C.charcoal }}>When do I overthink most?</p>
            <div className="grid grid-cols-2 gap-y-3 gap-x-6">
              {["At night / trying to sleep", "When I\u2019m alone with no distractions", "After social interactions", "Before something stressful", "When I\u2019m bored or understimulated", "When I feel like I messed something up"].map((item, i) => (
                <div key={i} className="flex items-center gap-2">
                  <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"><rect x="15" y="15" width="70" height="70" rx="8" /></svg>
                  <span className="text-[13px] text-gray-700">{item}</span>
                </div>
              ))}
              {[0,1].map(i => (
                <div key={`blank-${i}`} className="flex items-center gap-2">
                  <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"><rect x="15" y="15" width="70" height="70" rx="8" /></svg>
                  <div className="flex-grow border-b-[2px] border-dotted mt-3" style={{ borderColor: '#e2dec9' }}></div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-2xl p-5 border-2 shadow-sm mb-6" style={{ borderColor: '#e2dec9' }}>
            <p className="font-bold text-[15px] mb-3" style={{ color: C.charcoal }}>What do I tend to overthink about?</p>
            <div className="grid grid-cols-2 gap-y-3 gap-x-6">
              {([
                <>Replaying conversations</>,
                <>Rehearsing conversations</>,
                <>Things I need to do but haven&apos;t done</>,
                <>Whether people are upset with me</>,
                <>Past mistakes or embarrassing moments</>,
                <>Decisions I need to make</>,
                <>How someone&apos;s tone made me feel</>,
              ] as React.ReactNode[]).map((item, i) => (
                <div key={i} className="flex items-center gap-2">
                  <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"><rect x="15" y="15" width="70" height="70" rx="8" /></svg>
                  <span className="text-[13px] text-gray-700">{item}</span>
                </div>
              ))}
              {[0,1].map(i => (
                <div key={`blank-${i}`} className="flex items-center gap-2">
                  <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"><rect x="15" y="15" width="70" height="70" rx="8" /></svg>
                  <div className="flex-grow border-b-[2px] border-dotted mt-3" style={{ borderColor: '#e2dec9' }}></div>
                </div>
              ))}
            </div>
          </div>

          <div className="mb-6 px-5 py-4 rounded-xl text-[13px] italic" style={{ backgroundColor: '#ebf2ed', color: C.charcoal }}>
            If you checked &ldquo;whether people are upset with me&rdquo; or &ldquo;how someone&apos;s tone made me feel,&rdquo; you might be dealing with rejection sensitivity, which is incredibly common in ADHD. We touch on that in Chapter 7.
          </div>

          <div className="bg-white rounded-2xl p-5 border-2 shadow-sm mb-6" style={{ borderColor: '#e2dec9' }}>
            <p className="font-bold text-[15px] mb-3" style={{ color: C.charcoal }}>What&apos;s usually underneath the overthinking? <span className="font-normal text-gray-500 text-[13px]">(the feeling, not the topic)</span></p>
            <div className="grid grid-cols-2 gap-y-3 gap-x-6">
              {["Anxiety", "Shame", "Fear of getting it wrong", "Feeling out of control", "Loneliness", "Guilt about not doing enough"].map((item, i) => (
                <div key={i} className="flex items-center gap-2">
                  <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"><rect x="15" y="15" width="70" height="70" rx="8" /></svg>
                  <span className="text-[13px] text-gray-700">{item}</span>
                </div>
              ))}
              {[0,1].map(i => (
                <div key={`blank-${i}`} className="flex items-center gap-2">
                  <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"><rect x="15" y="15" width="70" height="70" rx="8" /></svg>
                  <div className="flex-grow border-b-[2px] border-dotted mt-3" style={{ borderColor: '#e2dec9' }}></div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* --- PAGE 40: CH6 WORKBOOK PAGE 2b — INTERRUPT PLAN --- */}
        <section className="worksheet-page min-h-[970px] relative px-20 pt-20 px-20 pt-12 flex flex-col pb-32" style={{ backgroundColor: C.cream }}>
          <p className="font-black uppercase tracking-[0.15em] text-sm mb-6 mt-10" style={{ color: C.sage }}>Part 2: Build Your Interrupt Plan</p>
          <p className="text-[16px] text-gray-700 mb-6">Now that you know your patterns, pick the strategies you&apos;ll use to break out of them. These are your tools for switching your brain back into doing mode.</p>

          <div className="bg-white rounded-2xl p-5 border-2 shadow-sm mb-6" style={{ borderColor: '#e2dec9' }}>
            <p className="font-bold text-[15px] mb-4" style={{ color: C.sage }}>My signal that I&apos;m stuck in a thought loop:</p>
            <div className="space-y-2">
              {[
                "I\u2019ve been staring at my to-do list for 10+ minutes without starting anything",
                "I\u2019m replaying something for the third time",
                "I can\u2019t fall asleep because my brain won\u2019t stop",
                "I feel overwhelmed but can\u2019t pinpoint why",
                "I\u2019m snapping at people over small things",
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-2">
                  <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"><rect x="15" y="15" width="70" height="70" rx="8" /></svg>
                  <span className="text-[13px] text-gray-700">{item}</span>
                </div>
              ))}
              <div className="flex items-center gap-2">
                <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"><rect x="15" y="15" width="70" height="70" rx="8" /></svg>
                <div className="flex-grow border-b-[2px] border-dotted mt-3" style={{ borderColor: '#e2dec9' }}></div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-5 border-[3px] shadow-sm mb-6" style={{ borderColor: C.goldLight }}>
            <p className="font-bold text-[15px]" style={{ color: C.sage }}>When I notice that signal, I will try:</p>
            <p className="text-[12px] italic text-gray-400 mb-4">Check the ones you&apos;re willing to try, then rank your top 3</p>
            <div className="space-y-2">
              {[
                "Brain dump \u2014 grab paper and get it all out of my head",
                "Move my body \u2014 walk, stretch, change rooms",
                "Name what\u2019s happening \u2014 say out loud what I\u2019m feeling (\u201cI\u2019m overthinking right now\u201d)",
                "Breathe in a pattern \u2014 inhale 6, hold 3, exhale 8, hold 3 (or pick your own: ___ - ___ - ___ - ___)",
                "Jot it down and move on \u2014 write the thought on my notepad and get back to my task",
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-2">
                  <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"><rect x="15" y="15" width="70" height="70" rx="8" /></svg>
                  <span className="text-[13px] text-gray-700">{item}</span>
                </div>
              ))}
              <div className="flex items-center gap-2">
                <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"><rect x="15" y="15" width="70" height="70" rx="8" /></svg>
                <span className="text-[13px] text-gray-700 flex-shrink-0">Something else that works for me:</span>
                <div className="flex-grow border-b-[2px] border-dotted mt-3" style={{ borderColor: '#e2dec9' }}></div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-5 border-2 shadow-sm mb-6" style={{ borderColor: '#e2dec9' }}>
            <p className="font-bold text-[15px] mb-4" style={{ color: C.sage }}>My top 3 interrupt strategies:</p>
            {[1,2,3].map(n => (
              <div key={n} className="flex items-end gap-3 mb-4">
                <span className={`${radley.className} font-bold text-[18px] flex-shrink-0`} style={{ color: C.sage }}>{n}.</span>
                <div className="flex-grow border-b-[2px] border-dotted mt-3" style={{ borderColor: '#e2dec9' }}></div>
              </div>
            ))}
            <p className="text-[12px] italic text-gray-400 mt-2">You don&apos;t have to use the same one every time. The point is knowing what&apos;s available to you before your brain is too loud to think of it.</p>
          </div>

          <div className="mt-auto p-5 rounded-2xl text-center border-t-[4px]" style={{ backgroundColor: '#ffffff', borderColor: C.sage }}>
            <p className="text-[15px] font-medium leading-relaxed text-gray-700">
              You just mapped your overthinking patterns and built an interrupt plan. Next up: what to do when one missed task somehow turns into proof that you&apos;re a terrible person — and how to climb back out before your brain rewrites your entire life story.
            </p>
          </div>
        </section>

        {/* =========================================================== */}
        {/* CHAPTER 7 */}
        {/* =========================================================== */}

        {/* --- CHAPTER 7 COVER --- */}
        <section className="chapter-title-page min-h-[970px] flex flex-col justify-center items-center text-center px-20 py-20" style={{ backgroundColor: C.cream }}>
          <h1 className={`${caveat.className} text-[110px] leading-none mb-10 tracking-wide drop-shadow-md`} style={{ color: C.charcoal }}>
            CHAPTER 7
          </h1>
          <h2 className={`${radley.className} text-[56px] italic drop-shadow-sm px-8 relative`} style={{ color: C.sage }}>
            The Shame Spiral (and How to Climb Out)
          </h2>
          <svg className="mt-12 w-48 h-12" viewBox="0 0 200 40" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M5 20 Q 50 5, 100 20 T 195 20" stroke={C.gold} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </section>

        {/* --- CHAPTER 7: THE BIT --- */}
        <section className="content-section min-h-[970px] relative px-20 pt-20 bg-white pb-32">
          <div className="space-y-4 text-[17px] leading-[1.6]">
            <h2 className={`${radley.className} text-[35px] mb-8 border-b-4 inline-block font-bold`} style={{ color: C.sage, borderColor: C.sage }}>THE BIT</h2>

            <p>Here&apos;s how it goes.</p>

            <p>You don&apos;t do the thing. Maybe it was the dishes. Maybe it was the email. Maybe it was the project that&apos;s been sitting in your to-do list for so long it&apos;s developed a personality. Whatever it was, you didn&apos;t do it. And at first, that&apos;s fine. You&apos;ll do it later. You&apos;ll do it tomorrow. No big deal.</p>

            <p>But then tomorrow comes and you still don&apos;t do it. And now it&apos;s not just a task. It&apos;s evidence. Evidence that you&apos;re the kind of person who can&apos;t follow through. Who says they&apos;ll do something and doesn&apos;t. Who has every tool, every system, every app, and still ends up here.</p>

            <p>So you stop thinking about the task and start thinking about yourself. What&apos;s wrong with me.</p>

            <p className={`${caveat.className} text-center text-[32px]`} style={{ color: C.charcoal }}>
              Why can&apos;t I just do this.
            </p>

            <p>Everyone else seems to manage. I&apos;m 30-something years old and I can&apos;t reply to an email.</p>

            <p>And here&apos;s the part that really gets you: the shame doesn&apos;t motivate you. It paralyzes you. The worse you feel about not doing the thing, the harder it becomes to do the thing. So you avoid it. You avoid the task, you avoid thinking about the task, you avoid the people connected to the task. And then you feel shame about the avoidance, which makes you avoid harder.</p>

            <div className="my-4 p-6 rounded-2xl shadow-sm border-l-[6px]" style={{ backgroundColor: C.goldLight, borderColor: C.gold }}>
              <p className="font-bold text-[20px] leading-snug" style={{ color: C.charcoal }}>
                That&apos;s the spiral. You didn&apos;t just fail at a task. You failed at a task, then decided it meant something about who you are, then let that meaning crush you, then couldn&apos;t move because you were being crushed. I call this one the Shame Spiraler.
              </p>
            </div>

            <p>...because one missed task turning into a full identity crisis by bedtime deserves a name. If you&apos;ve been here, this chapter is for you. And if you&apos;ve been here so many times you&apos;ve lost count, this chapter is especially for you.</p>
          </div>
        </section>

        {/* --- CHAPTER 7: THE REAL TALK --- */}
        <section className="content-section min-h-[970px] relative px-20 pt-20 pb-32" style={{ backgroundColor: C.cream }}>
          <div className="space-y-4 text-[17px] leading-[1.6]">
            <h2 className={`${radley.className} text-[35px] mb-8 border-b-4 inline-block font-bold`} style={{ color: C.sage, borderColor: C.sage }}>THE REAL TALK</h2>

            <p>Let&apos;s get something straight: the shame spiral is not a personality flaw. It&apos;s a predictable consequence of living with ADHD in a world that wasn&apos;t built for how your brain works.</p>

            <p className={`${caveat.className} text-center text-[30px]`} style={{ color: C.gold }}>
              ADHD brains don&apos;t just think differently.<br />They feel differently.
            </p>

            <p>Emotions hit harder, last longer, and are harder to regulate. Researchers have found that emotional dysregulation isn&apos;t a side effect of ADHD. It&apos;s a core feature of it <span className="uppercase text-xs opacity-60 tracking-wider font-bold">(Soler-Gutiérrez et al., 2023)</span>. Dr. Russell Barkley identified emotional self-regulation as one of the executive functions impaired in ADHD, right alongside working memory and impulse control <span className="uppercase text-xs opacity-60 tracking-wider font-bold">(Barkley, 1997)</span>. So when your emotional response to forgetting an appointment is a full-body wave of self-hatred, that&apos;s not you being dramatic. That&apos;s your brain doing what ADHD brains do: feeling everything at full volume with no dimmer switch.</p>

            <p>Dodson calls one specific version of this rejection sensitive dysphoria (RSD): a disproportionate emotional response to perceived rejection or criticism <span className="uppercase text-xs opacity-60 tracking-wider font-bold">(Dodson, 2016)</span>. But RSD is just one piece of it. The bigger picture is that your emotional responses are louder than the situation calls for, and when the loudest emotion is shame, it shuts everything down.</p>

            <div className="p-6 rounded-2xl shadow-sm border-l-[6px]" style={{ backgroundColor: '#ffffff', borderColor: C.gold }}>
              <p className="text-[18px] leading-snug font-medium" style={{ color: C.charcoal }}>
                A systematic review of women with undiagnosed ADHD found that many grew up with deep-rooted patterns of self-blame, guilt, and negative automatic thoughts like &ldquo;what&apos;s wrong with you&rdquo; and &ldquo;you&apos;re a failure&rdquo; <span className="uppercase text-xs opacity-60 tracking-wider font-bold">(Attoe &amp; Climie, 2023)</span>. While that study focused on women, these patterns aren&apos;t limited to one gender. Dr. Dodson estimates that children with ADHD receive 20,000 more corrective or negative messages than their peers by age 10 <span className="uppercase text-xs opacity-60 tracking-wider font-bold">(Dodson, 2016)</span>. By the time you&apos;re an adult, that&apos;s not just a number. It&apos;s a foundation made of &ldquo;something is wrong with me.&rdquo;
              </p>
            </div>

            <p>Here&apos;s why this matters for a book about doing stuff: when shame shows up, it doesn&apos;t push you to try harder. It makes you stop. Not the task itself. Not the boredom. Not the lack of a plan. The feeling that you&apos;ve already failed so many times that trying again seems pointless. And that&apos;s where we get stuck.</p>
          </div>
        </section>

        {/* --- CHAPTER 7: THE MANIPULATION --- */}
        <section className="content-section min-h-[970px] relative px-20 pt-20 bg-white pb-32">
          <div className="space-y-4 text-[17px] leading-[1.6]">
            <h2 className={`${radley.className} text-[35px] mb-6 border-b-4 inline-block font-bold`} style={{ color: C.sage, borderColor: C.sage }}>THE MANIPULATION</h2>

            <p>The shame spiral follows a pattern:</p>

            <div className="my-2 p-5 rounded-2xl shadow-sm border-l-[6px]" style={{ backgroundColor: C.goldLight, borderColor: C.gold }}>
              <p className="font-bold text-[19px] leading-relaxed" style={{ color: C.charcoal }}>
                I didn&apos;t do the thing → I&apos;m a terrible person → I can&apos;t face it → I avoid it → I feel worse → I avoid harder.
              </p>
            </div>

            <p>I&apos;m not here to fix that pattern for you. What I am here to do is help you see it clearly enough that you can start interrupting it yourself. Once you understand how the spiral works, you have choices inside it that you didn&apos;t know were there.</p>

            {[
              { title: "Separate the fact from the story.", body: <>The fact is: &ldquo;I didn&apos;t reply to the email.&rdquo; The story is: &ldquo;I&apos;m irresponsible and everyone can see it.&rdquo; When you catch yourself in the spiral, try pulling them apart. What actually happened? And what is your brain telling you it means? The fact is usually small. The story is where the damage lives. This is a core principle behind cognitive behavioral therapy — if the stories your brain tells you are running your life, CBT with a therapist who understands ADHD can be a game-changer.</> },
              { title: "Challenge the \u201calways\u201d and \u201cnever.\u201d", body: <>Shame loves absolutes. &ldquo;I always do this.&rdquo; &ldquo;I never follow through.&rdquo; When you hear those words, push back. Is it actually always? Can you think of one time it wasn&apos;t? You don&apos;t have to win the argument. You just have to cast enough doubt to weaken the case — like a lawyer introducing reasonable doubt so the jury (your brain) can&apos;t convict you with &ldquo;I always fail&rdquo; anymore.</> },
              { title: "Shrink the recovery step.", body: <>You don&apos;t have to fix everything. You just have to do one tiny thing that proves the spiral wrong. Reply with one sentence. Open the document. Put one dish in the sink. The goal isn&apos;t to catch up. The goal is to break the freeze. And if self-compassion isn&apos;t doing it for you, try spite. Your shame voice is telling you that you can&apos;t, that you won&apos;t, that you never do. Do the tiniest possible thing out of pure defiance. Once you do even one small thing, the spiral loses its grip.</> },
              { title: "Talk to yourself like you\u2019d talk to a friend.", body: <>If your friend told you they&apos;d been avoiding an email for two weeks and felt terrible about it, would you say &ldquo;yeah, you&apos;re a failure and you&apos;ll never change&rdquo;? No. You&apos;d say &ldquo;just send it now, it&apos;s not as bad as you think.&rdquo; Give yourself that same energy. Self-compassion isn&apos;t soft. It&apos;s strategic. Shame keeps you stuck. Compassion gets you moving.</> },
              { title: "Name the shame out loud.", body: <>&ldquo;I&apos;m in a shame spiral right now. I feel terrible about not doing this thing. That feeling is making it harder to do the thing.&rdquo; Naming it out loud <span className="uppercase text-xs opacity-60 tracking-wider font-bold">(Lieberman et al., 2011)</span> creates distance between you and the emotion. You&apos;re not the shame. You&apos;re a person noticing the shame. That&apos;s a different position to act from.</> },
            ].map((item, i) => (
              <div key={i} className="p-4 rounded-2xl border-2 shadow-sm" style={{ borderColor: '#e2dec9', backgroundColor: '#fafafa' }}>
                <p className="font-black text-[16px]" style={{ color: C.sage }}>{item.title}</p>
                <p className="text-[15px] leading-relaxed text-gray-700">{item.body}</p>
              </div>
            ))}

            <div className="px-6 py-4 rounded-xl italic text-[15px]" style={{ backgroundColor: '#ebf2ed', color: C.charcoal }}>
              <strong>Psst</strong>{' '}— if the shame spiral is feeling a little too intense right now — if it&apos;s constant, or it&apos;s bleeding into how you see yourself as a person — that&apos;s the kind of stuff a good therapist can really help with. You deserve more than white-knuckling it alone.
            </div>
          </div>
        </section>

        
        {/* Transition bridge — bottom of preceding content, NOT standalone */}
        <div className="mt-16 text-center pb-10 content-section">
<span className={`${caveat.className} text-[60px]`} style={{ color: C.gold }}>Let&apos;s get to it.</span>
          <span className="animate-bounce mt-6 text-6xl" style={{ color: C.sage }}>↓</span>
          <p className="text-center italic text-[20px] text-[#6B6B6B] max-w-2xl mx-auto leading-relaxed mt-8">
            Two exercises for this chapter. The first maps your spiral so you can see it clearly. The second builds your personal plan for climbing back out.
          </p>
        </div>


        {/* --- CHAPTER 7 WORKBOOK PAGE 1: The Shame Spiral Map --- */}
        <section className="worksheet-page min-h-[970px] relative px-20 pt-20 px-20 pt-12 flex flex-col bg-white pb-32">
          <h1 className={`${caveat.className} text-[55px] text-center mb-2 leading-tight mt-10 drop-shadow-sm`} style={{ color: C.charcoal }}>
            The Shame Spiral Map
          </h1>
          <p className="text-center font-black tracking-[0.2em] uppercase text-sm mb-6" style={{ color: C.sage }}>Reflection + Pattern Recognition</p>

          <div className="mb-5 p-5 rounded-3xl text-[16px] shadow-sm border-[3px] flex-shrink-0" style={{ borderColor: C.goldLight, backgroundColor: '#fafafa' }}>
            <p className="font-medium leading-snug"><span className="font-black text-sm uppercase tracking-widest" style={{ color: C.sage }}>Instructions: </span>Let&apos;s map out your spiral. Think about the last time you got stuck in one and walk through what actually happened, step by step.</p>
          </div>

          <div className="space-y-5 flex-grow flex flex-col">
            <div>
              <p className="font-bold text-[15px] mb-2" style={{ color: C.charcoal }}>What was the task I didn&apos;t do (or did &ldquo;badly&rdquo;)?</p>
              <div className="border-b-[2px] border-dotted mt-7" style={{ borderColor: '#e2dec9' }}></div>
              <div className="border-b-[2px] border-dotted mt-7" style={{ borderColor: '#e2dec9' }}></div>
            </div>

            <div>
              <p className="font-bold text-[15px]" style={{ color: C.charcoal }}>What story did my brain immediately tell me about it?</p>
              <p className="text-[12px] italic text-gray-400 mb-2">(example: &ldquo;I&apos;m lazy,&rdquo; &ldquo;I&apos;ll never get it together,&rdquo; &ldquo;everyone else can do this&rdquo;)</p>
              <div className="border-b-[2px] border-dotted mt-7" style={{ borderColor: '#e2dec9' }}></div>
              <div className="border-b-[2px] border-dotted mt-7" style={{ borderColor: '#e2dec9' }}></div>
            </div>

            <div className="bg-white rounded-2xl p-5 border-2 shadow-sm" style={{ borderColor: '#e2dec9' }}>
              <p className="font-bold text-[15px] mb-3" style={{ color: C.charcoal }}>What did I do next? <span className="font-normal text-[12px] text-gray-400">(check all that apply)</span></p>
              <div className="grid grid-cols-2 gap-2">
                {["Avoided the task entirely", "Avoided the people connected to the task", "Shut down (stayed in bed, scrolled, zoned out)", "Tried to distract myself from the feeling", "Beat myself up internally for hours or days", "Took it out on someone else"].map((item, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"><rect x="15" y="15" width="70" height="70" rx="8"/></svg>
                    <span className="text-[13px] text-gray-700">{item}</span>
                  </div>
                ))}
                <div className="flex items-center gap-2 col-span-2">
                  <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"><rect x="15" y="15" width="70" height="70" rx="8"/></svg>
                  <div className="flex-grow border-b-[2px] border-dotted mt-3" style={{ borderColor: '#e2dec9' }}></div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-5 border-2 shadow-sm" style={{ borderColor: '#e2dec9' }}>
              <p className="font-bold text-[15px] mb-3" style={{ color: C.charcoal }}>How long did the spiral last?</p>
              <div className="flex flex-wrap gap-4">
                {["A few hours", "A day", "Multiple days", "It\u2019s still going"].map((item, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"><rect x="15" y="15" width="70" height="70" rx="8"/></svg>
                    <span className="text-[13px] text-gray-700">{item}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-2xl p-5 border-[3px] shadow-sm" style={{ borderColor: C.goldLight }}>
              <p className="font-bold text-[15px] mb-4" style={{ color: C.sage }}>The fact vs. the story:</p>
              <div className="space-y-4">
                <div>
                  <p className="text-[13px] font-bold uppercase tracking-widest mb-2" style={{ color: C.charcoal }}>The fact <span className="font-normal normal-case opacity-60">(what actually happened, no interpretation)</span></p>
                  <div className="border-b-[2px] border-dotted mt-7" style={{ borderColor: '#e2dec9' }}></div>
                </div>
                <div>
                  <p className="text-[13px] font-bold uppercase tracking-widest mb-2" style={{ color: C.charcoal }}>The story <span className="font-normal normal-case opacity-60">(what my brain told me it meant)</span></p>
                  <div className="border-b-[2px] border-dotted mt-7" style={{ borderColor: '#e2dec9' }}></div>
                </div>
              </div>
              <div className="mt-8 space-y-6">
                <div>
                  <p className="font-bold text-[14px] text-gray-700">What do you notice from those two lines?</p>
                  <div className="border-b-[2px] border-dotted mt-7" style={{ borderColor: '#e2dec9' }}></div>
                </div>
                <div>
                  <p className="font-bold text-[14px] text-gray-700">Now, reframe the story so it&apos;s based off facts:</p>
                  <div className="border-b-[2px] border-dotted mt-7" style={{ borderColor: '#e2dec9' }}></div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* --- CHAPTER 7 WORKBOOK PAGE 2: My Getting Back Up Plan --- */}
        <section className="worksheet-page min-h-[970px] relative px-20 pt-20 px-20 pt-12 flex flex-col pb-32" style={{ backgroundColor: C.cream }}>
          <h1 className={`${caveat.className} text-[52px] text-center mb-2 leading-tight mt-10 drop-shadow-sm`} style={{ color: C.charcoal }}>
            My Getting Back Up Plan
          </h1>
          <p className="text-center font-black tracking-[0.2em] uppercase text-sm mb-6" style={{ color: C.sage }}>Action Planning</p>

          <div className="mb-5 p-5 rounded-3xl text-[16px] shadow-sm border-[3px] flex-shrink-0" style={{ borderColor: C.goldLight, backgroundColor: '#ffffff' }}>
            <p className="font-medium leading-snug"><span className="font-black text-sm uppercase tracking-widest" style={{ color: C.sage }}>Instructions: </span>Shame spirals are harder to interrupt when you&apos;re already in one. That&apos;s why we&apos;re building this plan now, while your head is clear.</p>
          </div>

          <div className="space-y-5 flex-grow flex flex-col">
            <div className="bg-white rounded-2xl p-5 border-2 shadow-sm" style={{ borderColor: '#e2dec9' }}>
              <p className="font-bold text-[15px] mb-3" style={{ color: C.sage }}>My shame triggers <span className="font-normal text-gray-500 text-[13px]">(what situations tend to start the spiral)</span></p>
              <div className="grid grid-cols-2 gap-2">
                {([
                  <>Missing a deadline</>,
                  <>Forgetting something important</>,
                  <>Feeling like I let someone down</>,
                  <>Comparing myself to other people</>,
                  <>Not following through on something I said<br />I&apos;d do</>,
                  <>Getting feedback or criticism</>,
                  <>Seeing how far behind I am</>,
                ] as React.ReactNode[]).map((item, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"><rect x="15" y="15" width="70" height="70" rx="8"/></svg>
                    <span className="text-[13px] text-gray-700">{item}</span>
                  </div>
                ))}
                {([0,1] as number[]).map(i => (
                  <div key={i} className="flex items-center gap-2">
                    <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"><rect x="15" y="15" width="70" height="70" rx="8"/></svg>
                    <div className="flex-grow max-w-[270px] border-b-[2px] border-dotted" style={{ borderColor: '#e2dec9' }}></div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-2xl p-5 border-[3px] shadow-sm" style={{ borderColor: C.goldLight }}>
              <p className="font-bold text-[15px]" style={{ color: C.sage }}>When I notice I&apos;m in the spiral, I will try:</p>
              <p className="text-[12px] italic text-gray-400 mb-3">Check the ones you&apos;re willing to use, then rank your top 3 below</p>
              <div className="space-y-2">
                {[
                  "Separate the fact from the story (what happened vs. what my brain says it means)",
                  "Challenge the \u201calways\u201d or \u201cnever\u201d (is it really always?)",
                  "Do one tiny recovery action (the smallest possible step)",
                  "Name the shame out loud (\u201cI\u2019m in a shame spiral right now\u201d)",
                  "Talk to myself like I\u2019d talk to a friend",
                  "Move my body (walk, stretch, change rooms)",
                  "Call or text someone I trust",
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"><rect x="15" y="15" width="70" height="70" rx="8"/></svg>
                    <span className="text-[13px] text-gray-700">{item}</span>
                  </div>
                ))}
                <div className="flex items-center gap-2">
                  <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"><rect x="15" y="15" width="70" height="70" rx="8"/></svg>
                  <span className="text-[13px] text-gray-700 flex-shrink-0">Something else:</span>
                  <div className="flex-grow border-b-[2px] border-dotted mt-3" style={{ borderColor: '#e2dec9' }}></div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-5 border-2 shadow-sm" style={{ borderColor: '#e2dec9' }}>
              <p className="font-bold text-[15px] mb-3" style={{ color: C.sage }}>My top 3 recovery strategies:</p>
              {[1,2,3].map(n => (
                <div key={n} className="flex items-center gap-3">
                  <span className={`${radley.className} font-bold text-xl flex-shrink-0`} style={{ color: C.sage }}>{n}.</span>
                  <div className="flex-grow border-b-[2px] border-dotted mt-3" style={{ borderColor: '#e2dec9' }}></div>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white rounded-2xl p-4 border-2 shadow-sm" style={{ borderColor: '#e2dec9' }}>
                <p className="font-bold text-[13px] mb-3" style={{ color: C.charcoal }}>The smallest possible recovery action for the thing I&apos;m currently avoiding:</p>
                <div className="border-b-[2px] border-dotted mt-4" style={{ borderColor: '#e2dec9' }}></div>
                <div className="border-b-[2px] border-dotted mt-4" style={{ borderColor: '#e2dec9' }}></div>
              </div>
              <div className="bg-white rounded-2xl p-4 border-2 shadow-sm" style={{ borderColor: '#e2dec9' }}>
                <p className="font-bold text-[13px]" style={{ color: C.charcoal }}>A sentence I can say to myself when the shame voice gets loud:</p>
                <p className="text-[11px] italic text-gray-400 mb-2">(example: &ldquo;The feeling is real. The story isn&apos;t.&rdquo;)</p>
                <div className="border-b-[2px] border-dotted mt-4" style={{ borderColor: '#e2dec9' }}></div>
                <div className="border-b-[2px] border-dotted mt-4" style={{ borderColor: '#e2dec9' }}></div>
              </div>
            </div>

            <div className="mt-auto p-5 rounded-2xl text-center border-t-[4px]" style={{ backgroundColor: '#ffffff', borderColor: C.sage }}>
              <p className="text-[15px] font-medium leading-relaxed text-gray-700">
                You don&apos;t have to feel better to start moving. You just have to move. Let the feeling catch up on its own time.{' '}
                You just mapped your shame spiral and built a plan for climbing out of the next one. Next up: building systems that don&apos;t collapse the first time you forget about them.
              </p>
            </div>
          </div>
        </section>

        {/* =========================================================== */}
        {/* CHAPTER 8 */}
        {/* =========================================================== */}

        {/* --- CHAPTER 8 COVER --- */}
        <section className="chapter-title-page min-h-[970px] flex flex-col justify-center items-center text-center px-20 py-20" style={{ backgroundColor: C.cream }}>
          <h1 className={`${caveat.className} text-[110px] leading-none mb-10 tracking-wide drop-shadow-md`} style={{ color: C.charcoal }}>
            CHAPTER 8
          </h1>
          <h2 className={`${radley.className} text-[56px] italic drop-shadow-sm px-8 relative`} style={{ color: C.sage }}>
            Building Systems That Actually Stick
          </h2>
          <svg className="mt-12 w-48 h-12" viewBox="0 0 200 40" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M5 20 Q 50 5, 100 20 T 195 20" stroke={C.gold} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </section>

        {/* --- CHAPTER 8: THE BIT --- */}
        <section className="content-section min-h-[970px] relative px-20 pt-20 bg-white pb-32">
          <div className="space-y-4 text-[17px] leading-[1.6]">
            <h2 className={`${radley.className} text-[35px] mb-8 border-b-4 inline-block font-bold`} style={{ color: C.sage, borderColor: C.sage }}>THE BIT</h2>

            <p>Be honest. How many productivity apps have you downloaded? How many planners have you bought? How many times have you tried bullet journaling, time blocking, the Pomodoro technique, the Eisenhower matrix, or some color-coded calendar system you found on TikTok? Have you ever spent an entire Sunday setting up a Notion dashboard so beautiful it could have been in a museum, only to use it for less than 2 days? Because same.</p>

            <p>The graveyard of abandoned systems in my life could fill a storage unit. Planners with two weeks of entries and then blank pages. Whiteboards that became background decoration. Reminder apps I stopped opening because the notifications stressed me out. Every single one worked for a little while. Then it didn&apos;t. And every time one stopped working, I assumed the problem was me. ...Sigh.</p>

            <div className="my-2 p-5 rounded-2xl shadow-sm border-l-[6px] text-center" style={{ backgroundColor: C.goldLight, borderColor: C.gold }}>
              <p className="font-bold text-[18px] leading-relaxed" style={{ color: C.charcoal }}>
                I call this one the System Hopper.
              </p>
            </div>

            <p>Here&apos;s the thing. Some of those systems were never going to work because they were built for brains that can just... do things. Planners that assume you&apos;ll open them every morning. Calendars that assume you&apos;ll check them. Routines that assume consistency is a thing you do. Cool. Love that for the neurotypical people.</p>

            <p>But here&apos;s the other thing, and this one stings a little more: even the systems that ARE built for ADHD brains &mdash; even the ones designed specifically for us &mdash; still stop working eventually. Because our brains are wired to chase novelty. Remember the interest-based nervous system from Chapter 2? It doesn&apos;t just apply to tasks. It applies to the systems we use to manage those tasks. The planner was exciting for two weeks. Then it wasn&apos;t. And we go looking for the next thing, hoping THIS one will be the one that finally sticks forever.</p>

            <p className={`${caveat.className} text-center text-[30px]`} style={{ color: C.gold }}>
              Spoiler: it won&apos;t.<br />And that&apos;s not a flaw. That&apos;s just how we&apos;re wired.
            </p>

            <p>This chapter isn&apos;t about finding the perfect system. There isn&apos;t one. It&apos;s about building something simple enough that you&apos;ll actually use it, flexible enough that it survives a bad week, and forgiving enough that you can come back to it after you inevitably abandon it for a while. Because the system that works isn&apos;t the prettiest one. It&apos;s the one you keep coming back to.</p>
          </div>
        </section>

        {/* --- CHAPTER 8: THE REAL TALK --- */}
        <section className="content-section min-h-[970px] relative px-20 pt-20 bg-white pb-32">
          <div className="space-y-4 text-[17px] leading-[1.6]">
            <h2 className={`${radley.className} text-[35px] mb-8 border-b-4 inline-block font-bold`} style={{ color: C.sage, borderColor: C.sage }}>THE REAL TALK</h2>

            <p>Before we go any further, let&apos;s define what we&apos;re actually talking about when we say &ldquo;system.&rdquo;</p>

            <div className="my-2 p-5 rounded-2xl shadow-sm border-l-[6px]" style={{ backgroundColor: C.goldLight, borderColor: C.gold }}>
              <p className="font-bold text-[18px] leading-relaxed" style={{ color: C.charcoal }}>
                A system is just a repeatable way of getting something done without relying on your brain to figure it out every time.
              </p>
            </div>

            <p>That&apos;s it. It&apos;s not an app. It&apos;s not a planner. It&apos;s not a morning routine you saw on TikTok. It&apos;s any structure that removes decisions from the moment and puts them somewhere external. Your system for paying bills might be automatic payments. Your system for remembering appointments might be one calendar with alerts. Your system for doing laundry might be &ldquo;when the basket is full, I start a load.&rdquo; Simple and effective. And sometimes, your system might also be knowing when to change the system.</p>

            <p>So why do systems keep failing for ADHD brains?</p>

            <p>Barkley&apos;s research makes a distinction that changes everything when you understand it:</p>

            <div className="my-2 p-5 rounded-2xl shadow-sm" style={{ backgroundColor: '#ebf2ed' }}>
              <p className="font-bold text-[18px] leading-relaxed" style={{ color: C.charcoal }}>
                ADHD isn&apos;t a problem of not knowing what to do. It&apos;s a problem of not being able to consistently do what you already know.
              </p>
              <p className="mt-2 text-xs uppercase opacity-60 tracking-wider font-bold">(Barkley, 1997)</p>
            </div>

            <p>You already know you should write things down. You know you should check your calendar. The gap isn&apos;t knowledge. It&apos;s performance. Systems exist to close that gap by taking the &ldquo;doing&rdquo; out of your hands as much as possible.</p>

            <p>Barkley recommends externalizing as much as possible: instead of relying on your brain to remember, organize, and follow through, you put everything outside your head where you can see it. <span className="uppercase text-xs opacity-60 tracking-wider font-bold">(Barkley, n.d.)</span>{' '} We&apos;ve talked about this in Chapters 3 and 6. This chapter is where we put it all together.</p>

            <p>But here&apos;s the part most ADHD advice leaves out: even good systems stop working. Not because they&apos;re broken. Because your brain stops responding to them. Novelty wears off. So the skill isn&apos;t finding the right system. The skill is knowing how to evaluate, adjust, and get back to your system when you fall off.</p>

            <p className={`${caveat.className} text-center text-[30px]`} style={{ color: C.gold }}>
              Stop chasing consistency.<br />Start chasing persistency.
            </p>

            <p>The goal isn&apos;t to never fall off. The goal is to keep getting back on. Consistency is a neurotypical standard. Persistency is the ADHD version, and it&apos;s the one that actually works.</p>
          </div>
        </section>

        {/* --- CHAPTER 8: THE MANIPULATION --- */}
        <section className="content-section min-h-[970px] relative px-20 pt-20 bg-white pb-32">
          <div className="space-y-4 text-[17px] leading-[1.6]">
            <h2 className={`${radley.className} text-[35px] mb-6 border-b-4 inline-block font-bold`} style={{ color: C.sage, borderColor: C.sage }}>THE MANIPULATION</h2>

            <p>The manipulation isn&apos;t one trick. It&apos;s a way of designing systems your brain can&apos;t easily reject, and that&apos;s what <strong>The 7 Commandments of ADHD Systems</strong> are for. The first five are for building, the last two for checking in, because a system that worked last month might not work now. Use this as a checklist to build and adjust your system.</p>

            <div className="text-center my-6">
              <p className="text-[11px] uppercase tracking-[0.25em] font-bold mb-2 opacity-50" style={{ color: C.charcoal }}>introducing</p>
              <h3 className={`${caveat.className} text-[52px] leading-tight`} style={{ color: C.charcoal }}>
                The 7 Commandments of<br />ADHD Systems
              </h3>
              <div className="mx-auto mt-3 w-24 h-[4px] rounded-full" style={{ backgroundColor: C.gold }}></div>
            </div>

            <div className="grid grid-cols-1 gap-3 mt-2">
              {([
                { num: 1, q: "Does it work on my worst day?", body: "If your system requires motivation, energy, or a good mood to function, it's not a system. It's a hope. Design for the version of you that has nothing left. If it works on that day, it works on every day.", build: true },
                { num: 2, q: "Can I see it without looking for it?", body: "If you have to open something, navigate somewhere, or remember where you put it, you've already lost. The best ADHD systems are visible by default. Remember Achor's guitar from Chapter 4? Out of sight is out of mind — with ADHD, that's literal.", build: true },
                { num: 3, q: "Does it live in one place?", body: "If your system involves tracking or organizing information, pick one home for it and stick to it. One notebook for your to-dos, not three. One app for your calendar, not two. Every extra place is another decision, and decisions cost executive function. Doesn't matter which one you pick, just that it's one.", build: true },
                { num: 4, q: "What's the smallest version that still counts?", body: "Whatever your system is, cut it in half. Then cut it in half again. That's your minimum. Everything above that is a bonus, not a requirement. Your morning routine can be: get up, drink water, look at your list. That's it. If it feels too simple, good.", build: true },
                { num: 5, q: "What's my re-entry point?", body: "You're going to fall off your system. That's not the problem. Not having a way back in is. Before that happens, decide on your re-entry micro step: the smallest version of your system that still counts. A 10-step skincare routine becomes \"splash water on my face.\" Write it down so it's waiting for you. That's persistency.", build: true },
                { num: 6, q: "When's the last time this actually helped me?", body: "If you can't answer that, it's either too complicated and needs to be stripped down, or it's run its course. A system you maintain out of obligation isn't serving you. It's just another thing on your list.", build: false },
                { num: 7, q: "Is this shiny object syndrome or a real failure?", body: "Novelty-seeking applies to systems too. Before you download the next app, ask: did the current system actually stop working, or am I just bored? Sometimes the fix is making the old one interesting again. Change the color. Move the whiteboard. Feed the novelty without scrapping the structure.", build: false },
              ] as { num: number; q: string; body: string; build: boolean }[]).map(({ num, q, body, build }) => (
                <div key={num} className="flex gap-3 p-4 rounded-2xl shadow-sm" style={{ backgroundColor: build ? C.cream : '#f0f6f3' }}>
                  <span className={`${radley.className} text-[26px] font-bold flex-shrink-0 leading-none mt-1`} style={{ color: C.gold }}>{num}</span>
                  <div>
                    <p className="font-bold text-[14px] mb-1" style={{ color: C.charcoal }}>{q}</p>
                    <p className="text-[13px] text-gray-600 leading-snug">{body}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* --- CHAPTER 8: TRANSITION --- */}
        <section className="content-section min-h-[970px] relative flex flex-col justify-center items-center gap-6 pb-32" style={{ backgroundColor: C.cream }}>
          <span className={`${caveat.className} text-[60px]`} style={{ color: C.gold }}>Let&apos;s get to it.</span>
          <span className="animate-bounce mt-6 text-6xl" style={{ color: C.sage }}>↓</span>
          <p className="text-center italic text-[20px] text-[#6B6B6B] max-w-2xl mx-auto leading-relaxed mt-8">
            Two exercises for this chapter. The first looks at what&apos;s failed before and why. The second builds your system from scratch.
          </p>
        </section>

        {/* --- CHAPTER 8: WORKBOOK PAGE 1 — My System Graveyard --- */}
        <section className="worksheet-page min-h-[970px] relative px-16 pt-16 flex flex-col gap-5 pb-32" style={{ backgroundColor: C.cream }}>
          <div>
            <h1 className={`${caveat.className} text-[60px] text-center mb-2 leading-tight drop-shadow-sm`} style={{ color: C.charcoal }}>My System Graveyard</h1>
            <p className="text-center font-black tracking-[0.2em] uppercase text-sm" style={{ color: C.sage }}>Reflection</p>
          </div>

          <div className="p-5 rounded-3xl text-[16px] shadow-sm border-[3px] flex-shrink-0" style={{ borderColor: C.goldLight, backgroundColor: '#ffffff' }}>
            <p className="font-medium leading-snug"><span className="font-black text-sm uppercase tracking-widest" style={{ color: C.sage }}>Instructions: </span>Before we build something new, let&apos;s look at what&apos;s failed before and figure out why. There&apos;s useful information in the wreckage.</p>
          </div>

          <table className="w-full border-collapse text-[14px] mb-4 flex-shrink-0">
            <thead>
              <tr style={{ backgroundColor: C.cream }}>
                <th className="text-left p-4 font-black uppercase tracking-wider text-[12px] border-b-2 rounded-tl-xl" style={{ color: C.sage, borderColor: '#e2dec9', width: '33%' }}>System / tool</th>
                <th className="text-left p-4 font-black uppercase tracking-wider text-[12px] border-b-2 border-l-2" style={{ color: C.sage, borderColor: '#e2dec9', width: '25%' }}>How long did it last?</th>
                <th className="text-left p-4 font-black uppercase tracking-wider text-[12px] border-b-2 border-l-2 rounded-tr-xl" style={{ color: C.sage, borderColor: '#e2dec9' }}>Why did it stop working?</th>
              </tr>
            </thead>
            <tbody>
              {([1,2,3] as number[]).map(n => (
                <tr key={n} className="border-b" style={{ borderColor: '#e2dec9' }}>
                  <td className="p-4 align-top" style={{ height: '80px' }}>
                    <span className={`${radley.className} font-bold text-xl`} style={{ color: C.sage }}>{n}.</span>
                  </td>
                  <td className="p-4 align-top border-l-2" style={{ borderColor: '#e2dec9', height: '80px' }}></td>
                  <td className="p-4 align-top border-l-2" style={{ borderColor: '#e2dec9', height: '80px' }}></td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="bg-white rounded-2xl p-5 border-2 shadow-sm" style={{ borderColor: '#e2dec9' }}>
            <p className="font-bold text-[15px] mb-3" style={{ color: C.sage }}>Do you notice a pattern? <span className="font-normal text-gray-500 text-[13px]">(check any that apply)</span></p>
            <div className="grid grid-cols-2 gap-2">
              {["They were too complicated", "They relied on me remembering to use them", "They required too many steps", "They only worked when I was motivated", "I got bored and needed novelty", "I felt bad when I missed a day and gave up entirely", "Life got chaotic and they were the first to go"].map((item, i) => (
                <div key={i} className="flex items-center gap-2">
                  <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"><rect x="15" y="15" width="70" height="70" rx="8"/></svg>
                  <span className="text-[13px] text-gray-700">{item}</span>
                </div>
              ))}
              {([0,1] as number[]).map(i => (
                <div key={i} className="flex items-center gap-2">
                  <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"><rect x="15" y="15" width="70" height="70" rx="8"/></svg>
                  <div className="flex-grow max-w-[270px] border-b-[2px] border-dotted" style={{ borderColor: '#e2dec9' }}></div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-2xl p-5 border-2 shadow-sm flex-grow" style={{ borderColor: '#e2dec9' }}>
            <p className="font-bold text-[15px] mb-2" style={{ color: C.sage }}>Knowing this, what would you do differently next time?</p>
            <div className="border-b-[2px] border-dotted mt-7" style={{ borderColor: '#e2dec9' }}></div>
            <div className="border-b-[2px] border-dotted mt-7" style={{ borderColor: '#e2dec9' }}></div>
            <div className="border-b-[2px] border-dotted mt-7" style={{ borderColor: '#e2dec9' }}></div>
          </div>
        </section>

        {/* --- CHAPTER 8: WORKBOOK PAGE 2 — Build Your System --- */}
        <section className="worksheet-page min-h-[970px] relative px-16 pt-16 flex flex-col gap-4 pb-32" style={{ backgroundColor: C.cream }}>
          <h1 className={`${caveat.className} text-[60px] text-center mb-2 leading-tight drop-shadow-sm`} style={{ color: C.charcoal }}>Build Your System</h1>

          <div className="p-5 rounded-3xl text-[16px] shadow-sm border-[3px] flex-shrink-0" style={{ borderColor: C.goldLight, backgroundColor: '#ffffff' }}>
            <p className="font-medium leading-snug"><span className="font-black text-sm uppercase tracking-widest" style={{ color: C.sage }}>Instructions: </span>Pick one area of your life that needs a system. Then run it through the 7 Commandments.</p>
          </div>

          <div className="bg-white rounded-2xl p-5 border-2 shadow-sm" style={{ borderColor: '#e2dec9' }}>
            <p className="font-bold text-[15px] mb-3" style={{ color: C.sage }}>The area I&apos;m building a system for:</p>
            <div className="grid grid-cols-2 gap-2">
              {["Morning routine", "Managing tasks / to-do's", "Keeping up with bills / admin", "Cleaning / household stuff", "Email / messages"].map((item, i) => (
                <div key={i} className="flex items-center gap-2">
                  <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"><rect x="15" y="15" width="70" height="70" rx="8"/></svg>
                  <span className="text-[13px] text-gray-700">{item}</span>
                </div>
              ))}
              <div className="flex items-center gap-2 col-span-2">
                <svg className="w-4 h-4 flex-shrink-0 opacity-40" viewBox="0 0 100 100" fill="none" stroke={C.sage} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"><rect x="15" y="15" width="70" height="70" rx="8"/></svg>
                <span className="text-[13px] text-gray-700 flex-shrink-0">Something else:</span>
                <div className="flex-grow border-b-[2px] border-dotted mt-3" style={{ borderColor: '#e2dec9' }}></div>
              </div>
            </div>
          </div>

          <div className="space-y-3 flex-grow flex flex-col">
            {([
              { n: 1, q: "Does it work on my worst day?", sub: "What's the bare minimum version?" },
              { n: 2, q: "Can I see it without looking for it?", sub: "Where will it live so I can't miss it?" },
              { n: 3, q: "Does it live in one place?", sub: "What's my one tool? (if applicable)" },
              { n: 4, q: "What's the smallest version that still counts?" },
            ] as { n: number; q: string; sub?: string }[]).map(({ n, q, sub }) => (
              <div key={n} className="bg-white rounded-xl px-5 pt-4 pb-3 border shadow-sm" style={{ borderColor: '#e2dec9' }}>
                <p className="font-bold text-[14px]" style={{ color: C.sage }}>#{n} — {q}</p>
                {sub && <p className="text-[12px] italic text-gray-400 mb-1">{sub}</p>}
                <div className="border-b-[2px] border-dotted mt-5" style={{ borderColor: '#e2dec9' }}></div>
              </div>
            ))}

            <div className="bg-white rounded-xl px-5 pt-4 pb-4 border-[3px] shadow-sm" style={{ borderColor: C.goldLight }}>
              <p className="font-bold text-[14px]" style={{ color: C.sage }}>#5 — What&apos;s my re-entry micro step?</p>
              <p className="text-[12px] italic text-gray-400 mb-3">The smallest possible version of this system that still counts as doing it. This is how you get back in when you fall off.</p>
              <div className="flex items-center gap-2">
                <span className="text-[13px] font-bold flex-shrink-0" style={{ color: C.sage }}>My re-entry micro step:</span>
                <div className="flex-grow border-b-[2px] border-dotted mt-3" style={{ borderColor: '#e2dec9' }}></div>
              </div>
            </div>

            {([
              { n: 6, q: "When's the last time this system actually helped me?", sub: "Does it need to be simplified or replaced? (if re-building)" },
              { n: 7, q: "How can I feed the novelty without scrapping the whole thing?", sub: "(if re-building a previous system)" },
            ] as { n: number; q: string; sub?: string }[]).map(({ n, q, sub }) => (
              <div key={n} className="bg-white rounded-xl px-5 pt-4 pb-3 border shadow-sm" style={{ borderColor: '#e2dec9' }}>
                <p className="font-bold text-[14px]" style={{ color: C.sage }}>#{n} — {q}</p>
                {sub && <p className="text-[12px] italic text-gray-400 mb-1">{sub}</p>}
                <div className="border-b-[2px] border-dotted mt-5" style={{ borderColor: '#e2dec9' }}></div>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-2xl p-5 border-2 shadow-sm" style={{ borderColor: '#e2dec9' }}>
            <p className="font-bold text-[15px] mb-1" style={{ color: C.sage }}>My system in one sentence:</p>
            <div className="border-b-[2px] border-dotted mt-6" style={{ borderColor: '#e2dec9' }}></div>
          </div>

          <div className="p-5 rounded-2xl text-center border-t-[4px]" style={{ backgroundColor: '#ffffff', borderColor: C.sage }}>
            <p className="text-[15px] font-medium leading-relaxed text-gray-700">
              You&apos;re not aiming for consistency. You&apos;re aiming for persistency. The system that works isn&apos;t the one you never abandon. It&apos;s the one you keep coming back to.{' '}
              You just built a system designed for your actual brain, not the brain you wish you had. Next up: your emergency kit for the days when none of this feels like enough.
            </p>
          </div>
        </section>


        {/* --- PAGE 51: CHAPTER 9 TITLE --- */}
        <section className="chapter-title-page min-h-[970px] flex flex-col justify-center items-center text-center px-20 py-20" style={{ backgroundColor: C.cream }}>
          <h1 className={`${caveat.className} text-[110px] leading-none mb-10 tracking-wide drop-shadow-md`} style={{ color: C.charcoal }}>
            CHAPTER 9
          </h1>
          <h2 className={`${radley.className} text-[56px] italic drop-shadow-sm px-8 relative`} style={{ color: C.sage }}>
            When You Can&apos;t Even Manipulate Yourself
          </h2>
          <svg className="mt-12 w-48 h-12" viewBox="0 0 200 40" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M5 20 Q 50 5, 100 20 T 195 20" stroke={C.gold} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </section>

        {/* --- PAGE 52: CHAPTER 9 — THE BIT --- */}
        <section className="content-section min-h-[970px] relative px-16 pt-16 bg-white flex flex-col pb-32">
          <div className="space-y-4 text-[17px] leading-[1.6]">
            <h2 className={`${radley.className} text-[35px] mb-6 border-b-4 inline-block font-bold`} style={{ color: C.sage, borderColor: C.sage }}>THE BIT</h2>

            <p>Whether you&apos;ve read every chapter or skipped straight to this one, here&apos;s what you&apos;ve got available to you: the bribes, the brain dumps, the 7 Commandments, the shame spiral map, the interrupt plan. You&apos;ve got tools. You&apos;ve got strategies. You&apos;ve got worksheets you may or may not have filled out yet (no judgment).</p>

            <div className="my-8 p-6 rounded-2xl border-l-[6px] shadow-sm" style={{ backgroundColor: '#ffffff', borderColor: C.gold }}>
              <p className="font-bold text-[20px] leading-[1.6]" style={{ color: C.charcoal }}>
                You can&apos;t start. You can&apos;t think. You can&apos;t even figure out which tool to reach for because your brain has decided to just... not. You&apos;re not in a shame spiral. You&apos;re not overthinking. You&apos;re just stuck. Fully, completely, can&apos;t-move stuck.
              </p>
            </div>

            <p>The Kit on the next page is for that day. No lessons. No research. No real talk. Just a list of things you can do right now, in the next five minutes, to get unstuck enough to do one thing. That&apos;s all we&apos;re going for. One thing.</p>
            
            <p>Screenshot The Kit below. Bookmark it. Whatever. Just know it&apos;s here for when you need it.</p>

            <div className="flex flex-col items-center justify-center mt-12 mb-4 w-full">
              <span className={`${caveat.className} text-[60px] leading-none text-center`} style={{ color: C.gold }}>Let&apos;s Get Unstuck!</span>
              <span className="animate-bounce mt-4 text-[50px] font-light" style={{ color: C.sage }}>↓</span>
            </div>
          </div>
        </section>

        {/* --- PAGE 53: CHAPTER 9 — THE KIT --- */}
        <section className="content-section min-h-[970px] relative px-16 pt-16 bg-white flex flex-col pb-32">
          <div className="space-y-4 text-[17px] leading-[1.6]">
            <h2 className={`${radley.className} text-[35px] mb-4 border-b-4 inline-block font-bold`} style={{ color: C.sage, borderColor: C.sage }}>THE KIT</h2>

            <div className="grid grid-cols-2 gap-x-6 gap-y-4 mt-6">
              {([
                { num: 1, title: "Stand up.", body: "That's it. Just stand up. Change your physical position. If you're in bed, put your feet on the floor. If you're on the couch, stand. You don't have to go anywhere yet. Just change the position your body is in." },
                { num: 2, title: "Pick one sense and use it.", body: "Splash cold water on your face. Drink something. Eat something crunchy. Put on a song. Open a window. You're trying to give your brain a signal that something has changed. Any sensory input will do." },
                { num: 3, title: "Name what's happening.", body: "Say it out loud if you can. \"I'm stuck right now.\" \"I don't know where to start.\" \"Everything feels too big.\" You know from Chapter 6 that naming it creates distance. Use that." },
                { num: 4, title: "Pick the smallest possible thing.", body: "Something so tiny your brain can't argue with it. Send one text. Put one thing away. Open one document. Wash one dish. You're not catching up. You're breaking the freeze." },
                { num: 5, title: "Defy the voice.", body: "You know that feeling when someone underestimates you and you instantly want to prove them wrong? That's the energy. Aim it at the voice in your head. Do the tiniest possible thing, not because you're ready, but because nothing fires you up like being told you can't." },
                { num: 6, title: "Move your body.", body: "From Chapter 6: even a short walk or a few stretches can interrupt the loop. You're not exercising. You're resetting." },
                { num: 7, title: "Breathe in a pattern.", body: "A few cycles of this can nudge you back into the task-positive network (the part of your brain that does things, from Chapter 6). Can't decide on a breathing pattern? Try: Inhale 6, hold 3, exhale 8, hold 3." },
                { num: 8, title: "Call in backup.", body: "Text someone. Call someone. Sit on a video call with a friend while you both work. Body doubling works even when nothing else does. You don't need them to help. You just need them to exist near you." },
                { num: 9, title: "Lower the bar.", body: "Whatever you think you need to do today, cut it in half. Then cut it in half again. That's your new goal. If you do more, great. If you don't, you still did something. Remember from Chapter 8: persistency, not consistency. You're getting back on, not catching up." },
                { num: 10, title: "Rest without guilt.", body: "Sometimes your brain and body genuinely need to stop. That's not failure. That's information. If every tool in this book isn't getting through today, maybe today isn't the day. Let it be. Tomorrow you try again. The tools will still be here." },
              ]).map(({ num, title, body }) => (
                <div key={num} className="bg-white rounded-2xl p-5 border-2 shadow-sm flex gap-5 items-start" style={{ borderColor: '#e2dec9' }}>
                  <div className={`${radley.className} text-[44px] font-bold leading-none mt-[-4px]`} style={{ color: C.gold }}>
                    {num}
                  </div>
                  <div className="flex-1">
                    <p className="font-bold text-[15px] mb-1" style={{ color: C.sage }}>{title}</p>
                    <p className="text-[13px] text-gray-600 leading-relaxed">{body}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* --- PAGE 54: CHAPTER 9 WORKBOOK PAGE — My Personal Emergency Kit --- */}
        <section className="worksheet-page min-h-[970px] relative px-16 pt-16 flex flex-col gap-4 pb-32" style={{ backgroundColor: C.cream }}>
          <div>
            <h1 className={`${caveat.className} text-[50px] text-center mb-1 leading-tight drop-shadow-sm`} style={{ color: C.charcoal }}>My Personal Emergency Kit</h1>
            <p className="text-center font-black tracking-[0.2em] uppercase text-sm mb-4" style={{ color: C.sage }}>Quick Reference Card</p>
          </div>

          <div className="p-4 rounded-3xl text-[15px] shadow-sm border-[3px] flex-shrink-0" style={{ borderColor: C.goldLight, backgroundColor: '#ffffff' }}>
            <p className="font-medium leading-snug"><span className="font-black text-sm uppercase tracking-widest" style={{ color: C.sage }}>Instructions: </span>Customize this so it&apos;s ready before you need it. When you&apos;re stuck, you won&apos;t have the energy to figure out what to do. This page does the figuring for you.</p>
          </div>

          <div className="space-y-4 flex-grow flex flex-col text-[14px]">
            <div className="bg-white rounded-xl px-5 pt-4 pb-3 border shadow-sm" style={{ borderColor: '#e2dec9' }}>
              <p className="font-bold" style={{ color: C.sage }}>My go-to sensory reset</p>
              <p className="text-[12px] italic text-gray-500 mb-2">(the thing that snaps me back to my body)</p>
              <div className="border-b-[2px] border-dotted mt-4" style={{ borderColor: '#e2dec9' }}></div>
            </div>

            <div className="bg-white rounded-xl px-5 pt-4 pb-3 border shadow-sm" style={{ borderColor: '#e2dec9' }}>
              <p className="font-bold" style={{ color: C.sage }}>My smallest possible task</p>
              <p className="text-[12px] italic text-gray-500 mb-2">(the thing I can always do, no matter how bad the day is, e.g. straighten up the sofa, bring 1 dish to the sink)</p>
              <div className="border-b-[2px] border-dotted mt-4" style={{ borderColor: '#e2dec9' }}></div>
            </div>

            <div className="bg-white rounded-xl px-5 pt-4 pb-3 border shadow-sm" style={{ borderColor: '#e2dec9' }}>
              <p className="font-bold" style={{ color: C.sage }}>My re-entry micro step</p>
              <p className="text-[12px] italic text-gray-500 mb-2">(the tiniest thing I can do to unfreeze and start moving again, e.g., drink a glass of water, get changed, step outside)</p>
              <div className="border-b-[2px] border-dotted mt-4" style={{ borderColor: '#e2dec9' }}></div>
            </div>

            <div className="bg-white rounded-xl px-5 pt-4 pb-3 border shadow-sm" style={{ borderColor: '#e2dec9' }}>
              <p className="font-bold" style={{ color: C.sage }}>My defiance fuel</p>
              <p className="text-[12px] italic text-gray-500 mb-2">(the thing my brain says I can&apos;t do that I want to prove wrong)</p>
              <div className="border-b-[2px] border-dotted mt-4" style={{ borderColor: '#e2dec9' }}></div>
            </div>

            <div className="bg-white rounded-xl px-5 pt-4 pb-3 border shadow-sm" style={{ borderColor: '#e2dec9' }}>
              <p className="font-bold" style={{ color: C.sage }}>My breathing pattern</p>
              <div className="flex items-center gap-4 mt-3">
                <div className="flex-1 flex items-end gap-2"><div className="border-b-[2px] border-dotted flex-grow" style={{ borderColor: '#e2dec9' }}></div><span className="text-gray-500">in,</span></div>
                <div className="flex-1 flex items-end gap-2"><div className="border-b-[2px] border-dotted flex-grow" style={{ borderColor: '#e2dec9' }}></div><span className="text-gray-500">hold,</span></div>
                <div className="flex-1 flex items-end gap-2"><div className="border-b-[2px] border-dotted flex-grow" style={{ borderColor: '#e2dec9' }}></div><span className="text-gray-500">out,</span></div>
                <div className="flex-1 flex items-end gap-2"><div className="border-b-[2px] border-dotted flex-grow" style={{ borderColor: '#e2dec9' }}></div><span className="text-gray-500">hold</span></div>
              </div>
            </div>

            <div className="bg-white rounded-xl px-5 pt-4 pb-3 border shadow-sm" style={{ borderColor: '#e2dec9' }}>
              <p className="font-bold" style={{ color: C.sage }}>My backup person</p>
              <p className="text-[12px] italic text-gray-500 mb-2">(the one I text or call when I&apos;m stuck)</p>
              <div className="flex items-end gap-2 mt-2">
                <span className="font-bold" style={{ color: C.charcoal }}>Name:</span>
                <div className="border-b-[2px] border-dotted flex-grow" style={{ borderColor: '#e2dec9' }}></div>
              </div>
            </div>

            <div className="bg-white rounded-xl px-5 pt-4 pb-4 border-[3px] shadow-sm" style={{ borderColor: C.goldLight }}>
              <p className="font-bold mb-2" style={{ color: C.sage }}>My permission slip</p>
              <div className="flex items-end gap-2">
                <span className="text-gray-700">If nothing works today, I am allowed to:</span>
                <div className="border-b-[2px] border-dotted flex-grow" style={{ borderColor: '#e2dec9' }}></div>
              </div>
              <p className="mt-3 text-gray-700 font-bold italic">And I will try again tomorrow.</p>
            </div>
          </div>
        </section>

        {/* --- PAGE 55: CONCLUSION --- */}
        <section className="content-section min-h-[970px] relative px-16 pt-16 bg-white flex flex-col justify-center text-center pb-32">
          <div className="max-w-2xl mx-auto space-y-6 text-[20px] leading-relaxed">
            <p>That&apos;s it. That&apos;s the whole book. Nine chapters of manipulating yourself into doing stuff. Some of it will work. Some of it won&apos;t. Some of it will work on Tuesday and not on Thursday. That&apos;s not a flaw in the system. That&apos;s just your brain being your brain.</p>

            <div className="my-8 py-8 px-6 rounded-2xl border-y-[4px]" style={{ borderColor: C.sage, backgroundColor: '#fdfbf7' }}>
              <p className="font-bold text-[24px] leading-snug" style={{ color: C.charcoal }}>
                The point was never to fix you. You were never broken.
              </p>
            </div>

            <p>The point was to give you enough tools that on any given day, at least one of them might be the thing that gets you moving.</p>

            <div className="mt-12">
              <span className={`${caveat.className} text-[60px]`} style={{ color: C.gold }}>Now go do one thing.</span><br/>
              <span className={`${caveat.className} text-[40px] opacity-80`} style={{ color: C.sage }}>Just one. You&apos;ve got this.</span>
            </div>
          </div>
        </section>

        {/* --- PAGE 56: WANT TO GO DEEPER --- */}
        <section className="content-section min-h-[970px] relative px-16 pt-16 bg-white flex flex-col justify-center pb-32">
          <div className="max-w-2xl mx-auto space-y-6 text-[18px] leading-relaxed relative">
            <h2 className={`${radley.className} text-[40px] mb-8 font-bold text-center`} style={{ color: C.sage }}>Want to go deeper?</h2>
            
            <p>Before you close this book, there&apos;s one last thing I want you to know: I didn&apos;t just write this from a place of theory. I wrote it from the trenches. I have ADHD, too. I know that feeling of being paralyzed by overwhelm. I&apos;ve been deep in the shame spiral, and I&apos;ve stared at my own graveyard of abandoned planners and broken systems.</p>
            
            <p>I became a coach because I wanted to help build the kind of support I wished I&apos;d had. If this book gave you hope, but also left you thinking, <em>&apos;I wish someone could just hold my hand and help me actually apply this,&apos;</em> please know you don&apos;t have to do it alone.</p>
            
            <p>I would love to be that person for you. Reach out, and let&apos;s figure it out together.</p>

            <div className="mt-10 p-8 rounded-2xl border-2 flex flex-col items-center text-center gap-4 bg-gray-50" style={{ borderColor: C.cream }}>
              <div className="w-32 h-32 border-4 bg-white relative flex items-center justify-center rounded-xl overflow-hidden" style={{ borderColor: C.goldLight }}>
                {/* QR Code Placeholder */}
                <span className="text-gray-400 text-sm font-bold z-0">QR CODE</span>
                <img src="/qr-code.png" alt="Scan to book a free consultation" className="absolute inset-0 w-full h-full object-cover z-10" onError={(e) => e.currentTarget.style.display = 'none'} />
              </div>
              <div>
                <p className="font-bold text-[18px]" style={{ color: C.charcoal }}>Scan to book a free consultation.</p>
              </div>
              <div className="mt-2 text-[14px] text-gray-500 space-y-1">
                <p>Website: <a href="https://www.lianagroombridge.com" className="underline" style={{ color: C.sage }}>www.lianagroombridge.com</a></p>
                <p>Email: <a href="mailto:hello@lianagroombridge.com" className="underline" style={{ color: C.sage }}>hello@lianagroombridge.com</a></p>
              </div>
            </div>
          </div>
        </section>

        {/* --- PAGE 57: REFERENCES --- */}
        <section className="front-matter-page relative px-16 pt-16 bg-white flex flex-col text-[12px] text-gray-600 leading-snug pb-32">
          <h2 className={`${radley.className} text-[30px] mb-6 font-bold uppercase tracking-widest`} style={{ color: C.charcoal }}>References</h2>
          

          <div className="space-y-4 pr-10">
            <p className="pl-4 -indent-4">Achor, S. (2010). The happiness advantage: The seven principles of positive psychology that fuel success and performance at work. Crown Business.</p>
            <p className="pl-4 -indent-4">Arnsten, A. F. T. (2009). The emerging neurobiology of attention deficit hyperactivity disorder: The key role of the prefrontal association cortex. The Journal of Pediatrics, 154(5), S22. https://doi.org/10.1016/j.jpeds.2009.01.018</p>
            <p className="pl-4 -indent-4">Attoe, D. E., &amp; Climie, E. A. (2023). Miss. Diagnosis: A systematic review of ADHD in adult women. Journal of Attention Disorders, 27(7), 645–657. https://doi.org/10.1177/10870547231161533</p>
            <p className="pl-4 -indent-4">Barkley, R. A. (n.d.). The important role of executive functioning and self-regulation in ADHD. RussellBarkley.org. https://www.russellbarkley.org/factsheets/ADHD_EF_and_SR.pdf</p>
            <p className="pl-4 -indent-4">Barkley, R. A. (1997). Behavioral inhibition, sustained attention, and executive functions: Constructing a unifying theory of ADHD. Psychological Bulletin, 121(1), 65–94. https://doi.org/10.1037/0033-2909.121.1.65</p>
            <p className="pl-4 -indent-4">Barkley, R. A., &amp; Benton, C. M. (2022). Taking charge of adult ADHD: Proven strategies to succeed at work, at home, and in relationships (2nd ed.). Guilford Press.</p>
            <p className="pl-4 -indent-4">Brand, S., Colledge, F., Ludyga, S., Emmenegger, R., Kalak, N., Sadeghi Bahmani, D., Holsboer-Trachsler, E., Pühse, U., &amp; Gerber, M. (2018). Acute bouts of exercising improved mood, rumination and social interaction in inpatients with mental disorders. Frontiers in Psychology, 9, 249. https://doi.org/10.3389/fpsyg.2018.00249</p>
            <p className="pl-4 -indent-4">Dodson, W. W. (2016). Emotional regulation and rejection sensitivity. CHADD. https://chadd.org/wp-content/uploads/2016/10/ATTN_10_16_EmotionalRegulation.pdf</p>
            <p className="pl-4 -indent-4">Dodson, W. W. (2022). How ADHD shapes your perceptions, emotions &amp; motivation [Webinar]. ADDitude Magazine. https://www.additudemag.com/webinar/adhd-symptoms-emotions-motivation/</p>
            <p className="pl-4 -indent-4">Hallowell, E. M., &amp; Ratey, J. J. (2021). ADHD 2.0: New science and essential strategies for thriving with distraction, from childhood through adulthood. Ballantine Books.</p>
            <p className="pl-4 -indent-4">Lieberman, M. D., Inagaki, T. K., Tabibnia, G., &amp; Crockett, M. J. (2011). Subjective responses to emotional stimuli during labeling, reappraisal, and distraction. Emotion, 11(3), 468–480. https://doi.org/10.1037/a0023503</p>
            <p className="pl-4 -indent-4">Miserandino, C. (2003). The spoon theory. But You Don&apos;t Look Sick. https://butyoudontlooksick.com/the_spoon_theory</p>
            <p className="pl-4 -indent-4">Netzer Turgeman, R., &amp; Pollak, Y. (2023). Using the temporal motivation theory to explain the relation between ADHD and procrastination. Australian Psychologist, 58(6), 448–456. https://doi.org/10.1080/00050067.2023.2218540</p>
            <p className="pl-4 -indent-4">Ramsay, J. R. (2020). Rethinking adult ADHD: Helping clients turn intentions into actions. American Psychological Association. https://doi.org/10.1037/0000158-000</p>
            <p className="pl-4 -indent-4">Soler-Gutiérrez, A. M., Pérez-González, J. C., &amp; Mayas, J. (2023). Evidence of emotion dysregulation as a core symptom of adult ADHD: A systematic review. PLoS ONE, 18(1), e0280131. https://doi.org/10.1371/journal.pone.0280131</p>
            <p className="pl-4 -indent-4">Volkow, N. D., Wang, G.-J., Newcorn, J. H., Kollins, S. H., Wigal, T. L., Telang, F., Fowler, J. S., Goldstein, R. Z., Klein, N., Logan, J., Wong, C., &amp; Swanson, J. M. (2011). Motivation deficit in ADHD is associated with dysfunction of the dopamine reward pathway. Molecular Psychiatry, 16(11), 1147–1154. https://doi.org/10.1038/mp.2010.97</p>
          </div>
        </section>
      </div>
    </div>
  );
}
